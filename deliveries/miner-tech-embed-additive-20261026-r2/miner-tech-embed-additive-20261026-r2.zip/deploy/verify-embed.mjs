// Read-only HTTP identity check for the additive embed site. Browser flow is separate.
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'..'),prefix='demos/tech-embed/site/';
const base=new URL(process.argv[2]);assert.ok(base.protocol==='https:'||(base.protocol==='http:'&&base.hostname==='127.0.0.1'),'HTTPS_OR_LOOPBACK_REQUIRED');assert.ok(base.pathname.endsWith('/'),'BASE_MUST_END_IN_SLASH');
const policy=JSON.parse(fs.readFileSync(path.join(root,prefix,'CSP.json'))).policy;
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2'};
const rows=fs.readFileSync(path.join(root,'FILES.sha256'),'utf8').trim().split(/\r?\n/).map(line=>({hash:line.slice(0,64),file:line.slice(66)})).filter(r=>r.file.startsWith(prefix));const results=[];
for(const row of rows){
 const file=row.file.slice(prefix.length),requestedUrl=new URL(file,base).href;
 const response=await fetch(requestedUrl,{redirect:'manual',signal:AbortSignal.timeout(20000),headers:{'Cache-Control':'no-cache'}});
 const body=Buffer.from(await response.arrayBuffer()),sha=createHash('sha256').update(body).digest('hex'),type=response.headers.get('content-type')??'',mediaType=type.split(';',1)[0].trim().toLowerCase(),csp=response.headers.get('content-security-policy');
 const extension=path.extname(file),allowedMime=extension==='.js'?['text/javascript','application/javascript']:mime[extension]?[mime[extension]]:null;
 results.push({file,requestedUrl,actualUrl:response.url,location:response.headers.get('location'),status:response.status,sha256:sha,mime:type,mediaType,csp,xFrameOptions:response.headers.get('x-frame-options'),pass:response.url===requestedUrl&&response.status===200&&sha===row.hash&&(!allowedMime||allowedMime.includes(mediaType))&&csp===policy&&!response.headers.get('x-frame-options')});
}
const missingRequestedUrl=new URL('__missing_embed_asset__.js',base).href;
const missing=await fetch(missingRequestedUrl,{redirect:'manual',signal:AbortSignal.timeout(20000)});await missing.body?.cancel();
const missingResult={requestedUrl:missingRequestedUrl,actualUrl:missing.url,location:missing.headers.get('location'),status:missing.status,pass:missing.url===missingRequestedUrl&&missing.status===404};
const pass=results.every(r=>r.pass)&&missingResult.pass;
console.log(JSON.stringify({pass,base:base.href,scope:'HTTP exact URL/no redirects/bytes/exact MIME/per-path CSP/no XFO/missing404; not browser or device acceptance',missingStatus:missing.status,missing:missingResult,results},null,2));if(!pass)process.exitCode=1;
