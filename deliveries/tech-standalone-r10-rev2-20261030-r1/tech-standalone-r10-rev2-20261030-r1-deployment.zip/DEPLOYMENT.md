# Tech R10 rev2 独立静态部署

site/ 的 124 个文件逐项来自原冻结总部署包 demos/tech/site/，未重新构建或修改产品；包括字体、许可证、CSP、清单和原 FILES.sha256。它不是新 Web H5 嵌入入口。

现有体验入口 https://tech.ektopod.cn/ 保持不变，本次不对它执行上传或切换。若未来迁移，完整发布 site/ 到获准的新独立版本目录，保留相对路径和各文件名。已有目录不覆盖；先核 SHA，冲突则停止。只公开 site/，不把说明或源码发布为站点。

HTTP Content-Security-Policy 使用 site/CSP.json 的 policy 原值；它的 frame-ancestors self 仅适用于原独立场景，不为接 Web H5 放宽旧路径。HTML/清单保持验证更新，静态资源策略沿部署方原约定；正确 JS/woff2/SVG MIME、目录末尾斜杠与实际缺失 404，不使用 SPA fallback。静态托管无需 Node 或维护依赖。

将来任何新迁移都需核 HTTPS/实际文件、进入/操作/退出；本次原字节打包不新增手机、浏览器性能、云回退或全站在线 SHA 验收声明。Web H5 需要专用嵌入适配，不直接把此独立首页当作 ready/活动控制入口。

原接受范围与历史未验项保留在 TECH-FREEZE.json；本次发布不扩签这些范围。只在将来获准切入口时更改引用，保留旧版本用于回退，不影响手机 H5 或已部署 Demo。
