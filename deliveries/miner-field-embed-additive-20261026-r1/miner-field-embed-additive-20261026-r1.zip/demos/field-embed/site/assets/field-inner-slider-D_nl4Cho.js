import EmblaCarousel from 'embla-carousel';

const DOMAIN_COUNT = 18;
const EXPECTED_DOMAIN_COUNT = DOMAIN_COUNT;
const SVG_NAMESPACE = 'http://www.w3.org/2000/svg';
const SNAP_TOLERANCE = 1e-9;
const NORMAL_TEXT_CLASS = 'st4 st566 st580';
const SELECTED_TEXT_CLASS = 'st45 st566 st581';
const SLOT_ROOTS = Object.freeze([
  { offset: -2, root: 27 },
  { offset: -1, root: 28 },
  { offset: 0, root: 26 },
  { offset: 1, root: 29 },
  { offset: 2, root: 30 },
]);
const TICK_KNOT_SPECS = Object.freeze([
  { phase: -2.5, root: 33 },
  { phase: -1.5, root: 32 },
  { phase: -0.5, root: 35 },
  { phase: 0.5, root: 37 },
  { phase: 1.5, root: 36 },
  { phase: 2.5, root: 34 },
]);
const LINE_ROOTS = Object.freeze([32, 33, 34, 35, 36, 37]);
const EXPECTED_TEXT_CLASS_BY_ROOT = Object.freeze({
  7: 'st4 st557 st563',
  26: 'st45 st566 st581',
  27: 'st4 st566 st580',
  28: 'st4 st566 st580',
  29: 'st4 st566 st580',
  30: 'st4 st566 st580',
});

await document.fonts.ready;

const mod = (value, divisor) =>
  ((value % divisor) + divisor) % divisor;

function registryIndexAtSlot(selectedIndex, slotOffset) {
  return 1 + mod(selectedIndex - 1 + slotOffset, DOMAIN_COUNT);
}

function resolveAuthorityTextNode(nodeByAuthoredRoot, root) {
  const rootNode = nodeByAuthoredRoot.get(root);
  const textNode = rootNode?.matches('text')
    ? rootNode
    : rootNode?.querySelector('text');

  if (!(textNode instanceof SVGTextElement)) {
    throw new Error(`FIELD_SLIDER_AUTHORITY_TEXT_MISSING: ${root}`);
  }

  if (textNode.getAttribute('class') !== EXPECTED_TEXT_CLASS_BY_ROOT[root]) {
    throw new Error(`FIELD_SLIDER_AUTHORITY_TEXT_CLASS_FAILED: ${root}`);
  }

  return textNode;
}

function readTextAnchor(textNode) {
  const transform = textNode.transform.baseVal.consolidate();
  const matrix = transform?.matrix;
  const advance = textNode.getComputedTextLength();

  if (
    !matrix ||
    matrix.a !== 1 ||
    matrix.b !== 0 ||
    matrix.c !== 0 ||
    matrix.d !== 1 ||
    !Number.isFinite(advance) ||
    advance <= 0
  ) {
    throw new Error('FIELD_SLIDER_TEXT_ANCHOR_FAILED');
  }

  return Object.freeze({
    centerX: matrix.e + advance / 2,
    baselineY: matrix.f,
  });
}

function setCenteredText(textNode, value, anchor) {
  textNode.textContent = value;

  const advance = textNode.getComputedTextLength();
  if (!Number.isFinite(advance) || advance <= 0) {
    throw new Error('FIELD_SLIDER_TEXT_ADVANCE_FAILED');
  }

  const nextX = anchor.centerX - advance / 2;
  textNode.setAttribute(
    'transform',
    `matrix(1 0 0 1 ${nextX} ${anchor.baselineY})`
  );
}

function correctedDiffToTarget({
  engine,
  slideIndex,
  scrollSnap,
  scrollProgress,
}) {
  let diff = scrollSnap - scrollProgress;

  if (!engine.options.loop) return diff;

  engine.slideLooper.loopPoints.forEach((loopItem) => {
    const target = loopItem.target();

    if (slideIndex !== loopItem.index || target === 0) {
      return;
    }

    const sign = Math.sign(target);

    if (sign === -1) {
      diff = scrollSnap - (1 + scrollProgress);
    }

    if (sign === 1) {
      diff = scrollSnap + (1 - scrollProgress);
    }
  });

  return diff;
}

function readSnapStep(emblaApi) {
  const snaps = emblaApi.scrollSnapList();

  if (snaps.length !== DOMAIN_COUNT) {
    throw new Error('FIELD_RULER_SNAP_COUNT_FAILED');
  }

  const step = snaps[1] - snaps[0];

  if (!Number.isFinite(step) || step <= 0) {
    throw new Error('FIELD_RULER_SNAP_STEP_FAILED');
  }

  for (let index = 1; index < snaps.length - 1; index += 1) {
    const candidate = snaps[index + 1] - snaps[index];

    if (Math.abs(candidate - step) > SNAP_TOLERANCE) {
      throw new Error('FIELD_RULER_NON_UNIFORM_SNAPS');
    }
  }

  return step;
}

const clamp01 = (value) => Math.max(0, Math.min(1, value));

function interpolateAuthorityPosition(authorityKnots, u) {
  const left = Math.max(-3, Math.min(2, Math.floor(u)));
  const right = left + 1;
  const t = u - left;
  const a = authorityKnots.get(left);
  const b = authorityKnots.get(right);

  return {
    centerX: a.centerX + (b.centerX - a.centerX) * t,
    baselineY: a.baselineY + (b.baselineY - a.baselineY) * t,
  };
}

function settledOffset(slideIndex, selectedIndex) {
  const raw = mod(slideIndex - selectedIndex, DOMAIN_COUNT);

  return raw > DOMAIN_COUNT / 2 ? raw - DOMAIN_COUNT : raw;
}

function createAuthorityRulerRenderer({
  registryRuntime,
  nodeByAuthoredRoot,
}) {
  const slotTextNodes = new Map(
    SLOT_ROOTS.map(({ root }) => [
      root,
      resolveAuthorityTextNode(nodeByAuthoredRoot, root),
    ])
  );
  const slotAnchors = new Map(
    SLOT_ROOTS.map(({ root }) => [
      root,
      readTextAnchor(slotTextNodes.get(root)),
    ])
  );
  const authorityKnots = new Map(
    SLOT_ROOTS.map(({ offset, root }) => [offset, slotAnchors.get(root)])
  );
  authorityKnots.set(
    -3,
    Object.freeze({
      centerX:
        2 * authorityKnots.get(-2).centerX -
        authorityKnots.get(-1).centerX,
      baselineY: authorityKnots.get(-2).baselineY,
    })
  );
  authorityKnots.set(
    3,
    Object.freeze({
      centerX:
        2 * authorityKnots.get(2).centerX -
        authorityKnots.get(1).centerX,
      baselineY: authorityKnots.get(2).baselineY,
    })
  );
  const selectedLabelNode = resolveAuthorityTextNode(
    nodeByAuthoredRoot,
    7
  );
  const selectedLabelAnchor = readTextAnchor(selectedLabelNode);
  const selectedLabelSnapshot = Object.freeze({
    textContent: selectedLabelNode.textContent,
    transform: selectedLabelNode.getAttribute('transform'),
  });
  const lineRootSnapshots = new Map(
    LINE_ROOTS.map((root) => {
      const rootNode = nodeByAuthoredRoot.get(root);
      if (!(rootNode instanceof SVGElement)) {
        throw new Error(`FIELD_SLIDER_AUTHORITY_LINE_ROOT_MISSING: ${root}`);
      }
      return [root, rootNode.outerHTML];
    })
  );
  const lineRootNodes = new Map(
    LINE_ROOTS.map((root) => [root, nodeByAuthoredRoot.get(root)])
  );
  const lineRootWrappers = new Map(
    LINE_ROOTS.map((root) => [root, lineRootNodes.get(root)?.parentElement])
  );
  const slotRootNodes = new Map(
    SLOT_ROOTS.map(({ root }) => [root, nodeByAuthoredRoot.get(root)])
  );
  const slotRootWrappers = new Map(
    SLOT_ROOTS.map(({ root }) => [root, slotRootNodes.get(root)?.parentElement])
  );
  const rulerTransform = slotRootWrappers.get(27)?.getAttribute('transform');
  const authoritySvg = slotRootWrappers.get(27)?.parentElement;

  if (
    rulerTransform !== 'translate(0 -16)' ||
    !(authoritySvg instanceof SVGSVGElement) ||
    SLOT_ROOTS.some(
      ({ root }) =>
        slotRootWrappers.get(root)?.parentElement !== authoritySvg ||
        slotRootWrappers.get(root)?.getAttribute('transform') !== rulerTransform
    )
  ) {
    throw new Error('FIELD_RULER_AUTHORITY_LAYER_FAILED');
  }

  if (
    TICK_KNOT_SPECS.some(
      ({ root }) =>
        lineRootWrappers.get(root)?.parentElement !== authoritySvg ||
        lineRootWrappers.get(root)?.getAttribute('transform') !==
          rulerTransform
    )
  ) {
    throw new Error('FIELD_RULER_TICK_AUTHORITY_LAYER_FAILED');
  }

  const tickKnots = Object.freeze(
    TICK_KNOT_SPECS.map(({ phase, root }) => {
      const sourceRoot = lineRootNodes.get(root);
      const bbox = sourceRoot.getBBox();
      const centerX = bbox.x + bbox.width / 2;

      if (
        !Number.isFinite(centerX) ||
        !Number.isFinite(bbox.y) ||
        bbox.width <= 0 ||
        bbox.height <= 0
      ) {
        throw new Error(`FIELD_RULER_TICK_BBOX_FAILED: ${root}`);
      }

      return Object.freeze({ phase, root, centerX });
    })
  );

  const originalVisibility = new Map(
    SLOT_ROOTS.map(({ root }) => [
      root,
      slotRootNodes.get(root).getAttribute('visibility'),
    ])
  );
  const originalTickWrapperVisibility = new Map(
    LINE_ROOTS.map((root) => [
      root,
      lineRootWrappers.get(root).getAttribute('visibility'),
    ])
  );
  const dynamicNumberLayer = document.createElementNS(SVG_NAMESPACE, 'g');
  dynamicNumberLayer.dataset.fieldRulerDynamic = 'true';
  dynamicNumberLayer.setAttribute('transform', rulerTransform);

  const ordinaryNumberTemplate = slotTextNodes.get(27);
  const numberNodes = registryRuntime.domains.map((entry) => {
    const node = ordinaryNumberTemplate.cloneNode(true);
    node.dataset.registryIndex = String(entry.index);
    node.textContent = String(entry.index).padStart(2, '0');
    dynamicNumberLayer.append(node);
    return node;
  });

  const tickTemplateDefs = document.createElementNS(SVG_NAMESPACE, 'defs');
  tickTemplateDefs.dataset.fieldRulerTickTemplates = 'true';
  const tickTemplateIdByRoot = new Map(
    tickKnots.map(({ root }) => {
      const templateId = `fm-field-ruler-tick-template-${root}`;
      const clone = lineRootNodes.get(root).cloneNode(true);

      if (authoritySvg.querySelector(`#${templateId}`)) {
        throw new Error(`FIELD_RULER_TICK_TEMPLATE_ID_FAILED: ${root}`);
      }

      clone.setAttribute('id', templateId);
      tickTemplateDefs.append(clone);
      return [root, templateId];
    })
  );

  const dynamicTickLayer = document.createElementNS(SVG_NAMESPACE, 'g');
  dynamicTickLayer.dataset.fieldRulerTickDynamic = 'true';
  dynamicTickLayer.setAttribute('transform', rulerTransform);
  const intervalNodes = registryRuntime.domains.map((entry) => {
    const group = document.createElementNS(SVG_NAMESPACE, 'g');
    const useA = document.createElementNS(SVG_NAMESPACE, 'use');
    const useB = document.createElementNS(SVG_NAMESPACE, 'use');

    group.dataset.registryIndex = String(entry.index);
    group.append(useA, useB);
    dynamicTickLayer.append(group);
    return Object.freeze({ group, useA, useB });
  });

  if (
    intervalNodes.length !== DOMAIN_COUNT ||
    dynamicTickLayer.querySelectorAll('use').length !== DOMAIN_COUNT * 2
  ) {
    throw new Error('FIELD_RULER_TICK_DOM_CONTRACT_FAILED');
  }

  authoritySvg.append(tickTemplateDefs, dynamicNumberLayer, dynamicTickLayer);
  SLOT_ROOTS.forEach(({ root }) => {
    slotRootNodes.get(root).setAttribute('visibility', 'hidden');
  });
  LINE_ROOTS.forEach((root) => {
    lineRootWrappers.get(root).setAttribute('visibility', 'hidden');
  });

  let destroyed = false;

  function assertLineRootsUnchanged() {
    LINE_ROOTS.forEach((root) => {
      if (
        nodeByAuthoredRoot.get(root).outerHTML !==
        lineRootSnapshots.get(root)
      ) {
        throw new Error(`FIELD_SLIDER_AUTHORITY_LINE_CHANGED: ${root}`);
      }
    });
  }

  function renderNodeAtU(node, u) {
    node.dataset.rulerU = String(u);

    if (Math.abs(u) >= 3) {
      node.setAttribute('visibility', 'hidden');
      return;
    }

    node.removeAttribute('visibility');

    const emphasis = clamp01(1 - Math.abs(u));
    const opacity = clamp01(3 - Math.abs(u));

    if (emphasis >= 1 - SNAP_TOLERANCE) {
      node.setAttribute('class', SELECTED_TEXT_CLASS);
      node.removeAttribute('style');
    } else if (emphasis <= SNAP_TOLERANCE) {
      node.setAttribute('class', NORMAL_TEXT_CLASS);
      node.removeAttribute('style');
    } else {
      const red = Math.round(247 - 61 * emphasis);
      const green = 247;
      const blue = Math.round(243 - 154 * emphasis);

      node.setAttribute('class', 'st566');
      node.style.fontSize = `${16 + 12 * emphasis}px`;
      node.style.fill = `rgb(${red} ${green} ${blue})`;
    }

    const position = interpolateAuthorityPosition(authorityKnots, u);
    const textAdvance = node.getComputedTextLength();

    if (!Number.isFinite(textAdvance) || textAdvance <= 0) {
      throw new Error('FIELD_RULER_TEXT_ADVANCE_FAILED');
    }

    const x = position.centerX - textAdvance / 2;
    node.setAttribute(
      'transform',
      `matrix(1 0 0 1 ${x} ${position.baselineY})`
    );
    node.setAttribute('opacity', String(opacity));
  }

  function renderIntervalAtV(intervalNode, v) {
    const { group, useA, useB } = intervalNode;
    group.dataset.rulerV = String(v);

    if (Math.abs(v) >= 3) {
      group.setAttribute('display', 'none');
      return;
    }

    group.removeAttribute('display');

    let segmentIndex;
    if (v <= tickKnots[0].phase) {
      segmentIndex = 0;
    } else if (v >= tickKnots[tickKnots.length - 1].phase) {
      segmentIndex = tickKnots.length - 2;
    } else {
      segmentIndex = tickKnots.findIndex(
        (knot, index) =>
          index < tickKnots.length - 1 &&
          knot.phase <= v &&
          v <= tickKnots[index + 1].phase
      );
    }

    if (segmentIndex < 0) {
      throw new Error('FIELD_RULER_TICK_SEGMENT_FAILED');
    }

    const a = tickKnots[segmentIndex];
    const b = tickKnots[segmentIndex + 1];
    const rawT = (v - a.phase) / (b.phase - a.phase);
    const mixT = clamp01(rawT);
    const x = a.centerX + (b.centerX - a.centerX) * rawT;
    const edgeAlpha = clamp01(2 * (3 - Math.abs(v)));

    useA.setAttribute('href', `#${tickTemplateIdByRoot.get(a.root)}`);
    useA.setAttribute('transform', `translate(${x - a.centerX} 0)`);
    useA.setAttribute('opacity', String(edgeAlpha * (1 - mixT)));

    useB.setAttribute('href', `#${tickTemplateIdByRoot.get(b.root)}`);
    useB.setAttribute('transform', `translate(${x - b.centerX} 0)`);
    useB.setAttribute('opacity', String(edgeAlpha * mixT));
  }

  function renderFrame(emblaApi) {
    if (destroyed) return;

    const engine = emblaApi.internalEngine();
    const scrollProgress = emblaApi.scrollProgress();
    const scrollSnaps = emblaApi.scrollSnapList();
    const snapStep = readSnapStep(emblaApi);

    numberNodes.forEach((node, slideIndex) => {
      const diff = correctedDiffToTarget({
        engine,
        slideIndex,
        scrollSnap: scrollSnaps[slideIndex],
        scrollProgress,
      });
      const u = diff / snapStep;

      renderNodeAtU(node, u);
      renderIntervalAtV(intervalNodes[slideIndex], u + 0.5);
    });

    assertLineRootsUnchanged();
  }

  function renderSettledFrame(emblaApi) {
    if (destroyed) return;

    const selectedIndex = emblaApi.selectedScrollSnap();

    numberNodes.forEach((node, slideIndex) => {
      const u = settledOffset(slideIndex, selectedIndex);
      renderNodeAtU(node, u);
      renderIntervalAtV(intervalNodes[slideIndex], u + 0.5);
    });

    assertLineRootsUnchanged();
  }

  function syncLabel(registryIndex) {
    setCenteredText(
      selectedLabelNode,
      registryRuntime.domains[registryIndex - 1].domain,
      selectedLabelAnchor
    );
  }

  function destroy() {
    if (destroyed) return;
    destroyed = true;

    SLOT_ROOTS.forEach(({ root }) => {
      const rootNode = slotRootNodes.get(root);
      const visibility = originalVisibility.get(root);

      if (visibility === null) {
        rootNode.removeAttribute('visibility');
      } else {
        rootNode.setAttribute('visibility', visibility);
      }
    });

    LINE_ROOTS.forEach((root) => {
      const wrapper = lineRootWrappers.get(root);
      const visibility = originalTickWrapperVisibility.get(root);

      if (visibility === null) {
        wrapper.removeAttribute('visibility');
      } else {
        wrapper.setAttribute('visibility', visibility);
      }
    });

    selectedLabelNode.textContent = selectedLabelSnapshot.textContent;
    selectedLabelNode.setAttribute(
      'transform',
      selectedLabelSnapshot.transform
    );
    dynamicTickLayer.remove();
    tickTemplateDefs.remove();
    dynamicNumberLayer.remove();
  }

  return Object.freeze({
    renderFrame,
    renderSettledFrame,
    syncLabel,
    destroy,
  });
}

function createLayoutContractRulerRenderer({
  registryRuntime,
  sliderSlots,
}) {
  if (
    sliderSlots?.layoutId !== 'landscape-1920x1080'
    || typeof sliderSlots.renderFrame !== 'function'
    || typeof sliderSlots.renderSettledFrame !== 'function'
    || typeof sliderSlots.syncLabel !== 'function'
    || typeof sliderSlots.destroy !== 'function'
  ) {
    throw new Error('FIELD_SLIDER_LAYOUT_SLOT_CONTRACT_FAILED');
  }

  function movingItems(emblaApi) {
    const engine = emblaApi.internalEngine();
    const scrollProgress = emblaApi.scrollProgress();
    const scrollSnaps = emblaApi.scrollSnapList();
    const snapStep = readSnapStep(emblaApi);

    return registryRuntime.domains.map((entry, slideIndex) => {
      const diff = correctedDiffToTarget({
        engine,
        slideIndex,
        scrollSnap: scrollSnaps[slideIndex],
        scrollProgress,
      });
      return Object.freeze({
        registryIndex: entry.index,
        u: diff / snapStep,
      });
    });
  }

  function settledItems(emblaApi) {
    const selectedIndex = emblaApi.selectedScrollSnap();
    return registryRuntime.domains.map((entry, slideIndex) =>
      Object.freeze({
        registryIndex: entry.index,
        u: settledOffset(slideIndex, selectedIndex),
      }));
  }

  return Object.freeze({
    renderFrame(emblaApi) {
      sliderSlots.renderFrame(movingItems(emblaApi));
    },
    renderSettledFrame(emblaApi) {
      sliderSlots.renderSettledFrame(settledItems(emblaApi));
    },
    syncLabel(registryIndex) {
      sliderSlots.syncLabel(
        registryIndex,
        registryRuntime.domains[registryIndex - 1].domain,
      );
    },
    destroy() {
      sliderSlots.destroy();
    },
  });
}

function assertMountContract({
  surface,
  registryRuntime,
  nodeByAuthoredRoot,
  sliderSlots,
  initialIndex,
  onSelectionChange,
}) {
  if (!(surface instanceof HTMLElement)) {
    throw new Error('FIELD_SLIDER_SURFACE_MISSING');
  }

  if (
    !registryRuntime ||
    !Array.isArray(registryRuntime.domains) ||
    registryRuntime.domains.length !== EXPECTED_DOMAIN_COUNT ||
    typeof registryRuntime.select !== 'function'
  ) {
    throw new Error('FIELD_SLIDER_REGISTRY_CONTRACT_FAILED');
  }

  const contiguous = registryRuntime.domains.every(
    (entry, offset) => entry.index === offset + 1
  );

  if (!contiguous) {
    throw new Error('FIELD_SLIDER_REGISTRY_INDEX_FAILED');
  }

  if (
    sliderSlots == null
    && (
      !(nodeByAuthoredRoot instanceof Map)
      || nodeByAuthoredRoot.size !== 38
    )
  ) {
    throw new Error('FIELD_SLIDER_AUTHORITY_MAP_FAILED');
  }

  if (
    !Number.isInteger(initialIndex) ||
    initialIndex < 1 ||
    initialIndex > registryRuntime.domains.length ||
    registryRuntime.selection.entry.index !== initialIndex
  ) {
    throw new Error('FIELD_SLIDER_INITIAL_INDEX_FAILED');
  }

  if (typeof onSelectionChange !== 'function') {
    throw new Error('FIELD_SLIDER_SELECTION_CALLBACK_MISSING');
  }
}

function createSliderDom(domains) {
  const viewport = document.createElement('div');
  viewport.className = 'fm-domain-slider__viewport';
  viewport.tabIndex = 0;
  viewport.setAttribute('role', 'listbox');
  viewport.setAttribute('aria-label', '选择发生场');
  viewport.setAttribute('aria-orientation', 'horizontal');

  const container = document.createElement('div');
  container.className = 'fm-domain-slider__container';

  const options = domains.map((entry) => {
    const option = document.createElement('div');
    option.className = 'fm-domain-slider__option';
    option.id =
      `fm-domain-option-${String(entry.index).padStart(2, '0')}`;
    option.dataset.registryIndex = String(entry.index);
    option.setAttribute('role', 'option');
    option.setAttribute('aria-selected', 'false');
    option.textContent = String(entry.index).padStart(2, '0');
    container.append(option);
    return option;
  });

  viewport.append(container);

  const selectionStatus = document.createElement('output');
  selectionStatus.className =
    'fm-domain-slider__selection-status';
  selectionStatus.setAttribute('aria-live', 'polite');
  selectionStatus.setAttribute('aria-atomic', 'true');

  return {
    viewport,
    container,
    options,
    selectionStatus,
  };
}

export function mountFieldInnerSlider({
  surface,
  registryRuntime,
  nodeByAuthoredRoot,
  sliderSlots = null,
  initialIndex,
  onSelectionChange,
  initialActive = true,
}) {
  assertMountContract({
    surface,
    registryRuntime,
    nodeByAuthoredRoot,
    sliderSlots,
    initialIndex,
    onSelectionChange,
  });

  const {
    viewport,
    container,
    options,
    selectionStatus,
  } = createSliderDom(registryRuntime.domains);
  const rulerRenderer = sliderSlots
    ? createLayoutContractRulerRenderer({
        registryRuntime,
        sliderSlots,
      })
    : createAuthorityRulerRenderer({
        registryRuntime,
        nodeByAuthoredRoot,
      });

  if (sliderSlots) {
    const { x, y, width, height } = sliderSlots.interactionRect;
    viewport.style.left = `${x}px`;
    viewport.style.top = `${y}px`;
    viewport.style.width = `${width}px`;
    viewport.style.height = `${height}px`;
    const slideWidth = Math.round(width / 6);
    options.forEach((option) => {
      option.style.flexBasis = `${slideWidth}px`;
    });
  }

  surface.append(viewport, selectionStatus);

  let currentSelection = registryRuntime.selection;
  let active = true, disposed = false;
  const lifetime = new AbortController();

  const emblaApi = EmblaCarousel(viewport, {
    axis: 'x',
    align: 'center',
    loop: true,
    dragFree: false,
    slidesToScroll: 1,
    skipSnaps: false,
    startIndex: initialIndex - 1,
    duration: 25,
  });

  const snapCount = emblaApi.scrollSnapList().length;
  const actualLoop = emblaApi.internalEngine().options.loop;

  if (snapCount !== registryRuntime.domains.length || !actualLoop) {
    emblaApi.destroy();
    rulerRenderer.destroy();
    throw new Error(
      `FIELD_SLIDER_EMBLA_CONTRACT_FAILED: ${snapCount}/${actualLoop}`
    );
  }

  const renderFrame = (api) => {
    rulerRenderer.renderFrame(api);
  };
  const renderSettledFrame = (api) => {
    rulerRenderer.renderSettledFrame(api);
  };

  function syncSelection() {
    const registryIndex = emblaApi.selectedScrollSnap() + 1;

    currentSelection = registryRuntime.select(registryIndex);
    rulerRenderer.syncLabel(registryIndex);
    rulerRenderer.renderFrame(emblaApi);
    surface.dataset.domainIndex = String(currentSelection.entry.index);

    options.forEach((option) => {
      const selected =
        Number(option.dataset.registryIndex) === registryIndex;
      option.setAttribute('aria-selected', String(selected));
    });

    viewport.setAttribute(
      'aria-activedescendant',
      options[registryIndex - 1].id
    );

    selectionStatus.textContent =
      `D${String(registryIndex).padStart(2, '0')} ` +
      currentSelection.entry.domain;
    onSelectionChange(currentSelection);
  }

  options.forEach((option, offset) => {
    option.addEventListener('click', () => {
      if (active && !disposed) emblaApi.scrollTo(offset);
    }, {signal:lifetime.signal});
  });

  viewport.addEventListener('keydown', (event) => {
    if (!active || disposed) return;
    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      emblaApi.scrollPrev();
    }

    if (event.key === 'ArrowRight') {
      event.preventDefault();
      emblaApi.scrollNext();
    }

    if (event.key === 'Home') {
      event.preventDefault();
      emblaApi.scrollTo(0, true);
    }

    if (event.key === 'End') {
      event.preventDefault();
      emblaApi.scrollTo(registryRuntime.domains.length - 1, true);
    }
  });

  emblaApi
    .on('select', syncSelection)
    .on('reInit', renderFrame)
    .on('scroll', renderFrame)
    .on('slideFocus', renderFrame)
    .on('settle', renderSettledFrame);
  syncSelection();

  function setActivity(value) {
    if (disposed || active === value) return;
    const selected = emblaApi.selectedScrollSnap();
    active = Boolean(value); viewport.inert = !active;
    emblaApi.reInit({active, startIndex:selected});
  }
  setActivity(initialActive);
  return Object.freeze({
    setActivity,
    get active() { return active && !disposed; },
    destroy() {
      if (disposed) return;
      disposed = true; active = false; lifetime.abort();
      emblaApi.destroy();
      rulerRenderer.destroy();
      viewport.remove();
      selectionStatus.remove();
    },
  });
}
