import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=path.resolve(import.meta.dirname,'..');
const hash=b=>createHash('sha256').update(b).digest('hex');
const id=value=>{assert.match(value,/^release-[A-Za-z0-9_-]+$/,'RELEASE_ID_INVALID');return value;};
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{
 assert.ok(!e.isSymbolicLink(),'SYMLINK_REJECTED');return e.isDirectory()?walk(path.join(dir,e.name)).map(f=>e.name+'/'+f):[e.name];
}).sort();}
const recordPath=(releaseRoot,releaseId)=>path.join(path.resolve(releaseRoot),'.release-records',id(releaseId)+'.json');
function manifestRows(text){
 const rows=text.trim().split(/\r?\n/).map(line=>{
  const match=/^([a-f0-9]{64})  (.+)$/.exec(line);assert.ok(match,'INPUT_MANIFEST_FORMAT');
  assert.ok(!path.isAbsolute(match[2])&&!match[2].includes('\\')&&!match[2].split('/').some(p=>['..','.',''].includes(p)),'INPUT_MANIFEST_PATH');
  return {file:match[2],sha256:match[1]};
 });assert.equal(new Set(rows.map(r=>r.file)).size,rows.length,'INPUT_MANIFEST_DUPLICATE');return rows;
}
const siteRows=rows=>rows.filter(r=>/^demos\/(field|tech|tech-embed|field-embed)\/site\//.test(r.file)).map(r=>({...r,file:r.file.replace(/^demos\/(field|tech|tech-embed|field-embed)\/site\//,'$1/')}));
export function verifyRelease(releaseRoot,releaseId){
 const target=path.resolve(releaseRoot,id(releaseId));
 const record=JSON.parse(fs.readFileSync(recordPath(releaseRoot,releaseId),'utf8'));
 assert.equal(record.schemaVersion,1,'RELEASE_RECORD_SCHEMA');assert.equal(record.releaseId,releaseId,'RELEASE_RECORD_IDENTITY');
 assert.equal(hash(Buffer.from(record.input.manifest)),record.input.manifestSha256,'INPUT_IDENTITY_MISMATCH');
 const inputRows=manifestRows(record.input.manifest);
 assert.equal(hash(Buffer.from(record.input.versionIndex)),inputRows.find(r=>r.file==='VERSION-INDEX.json')?.sha256,'INPUT_VERSION_IDENTITY');
 assert.equal(JSON.parse(record.input.versionIndex).id,record.input.id,'INPUT_VERSION_IDENTITY');
 const rows=siteRows(inputRows);assert.ok(rows.length,'EMPTY_RELEASE_RECORD');
 assert.deepEqual(record.files,rows,'RELEASE_RECORD_FILE_IDENTITY');
 assert.ok(!fs.lstatSync(target).isSymbolicLink(),'SYMLINK_REJECTED');
 const demos=[...new Set(rows.map(row=>row.file.split('/')[0]))].sort();
 assert.ok(demos.includes('field')&&demos.includes('tech')&&demos.every(d=>['field','tech','tech-embed','field-embed'].includes(d)),'RELEASE_DEMOS_INVALID');
 assert.deepEqual(fs.readdirSync(target).sort(),demos,'RELEASE_ROOT_SET');
 for(const demo of demos){
  const destination=path.join(target,demo),expected=rows.filter(r=>r.file.startsWith(demo+'/'));
  assert.ok(!fs.lstatSync(destination).isSymbolicLink(),'SYMLINK_REJECTED');
  assert.ok(expected.length,'EMPTY_DEMO_RECORD');assert.deepEqual(walk(destination),expected.map(r=>r.file.slice(demo.length+1)).sort(),'RELEASE_FILE_SET');
  for(const row of expected)assert.equal(hash(fs.readFileSync(path.join(target,row.file))),row.sha256,'RELEASE_HASH '+row.file);
 }
 assert.equal(record.techCsp,JSON.parse(fs.readFileSync(path.join(target,'tech/CSP.json'))).policy,'RELEASE_CSP_IDENTITY');
 if(demos.includes('tech-embed'))assert.equal(record.techEmbedCsp,JSON.parse(fs.readFileSync(path.join(target,'tech-embed/CSP.json'))).policy,'EMBED_CSP_IDENTITY');
 if(demos.includes('field-embed'))assert.equal(record.fieldEmbedCsp,JSON.parse(fs.readFileSync(path.join(target,'field-embed/CSP.json'))).policy,'FIELD_EMBED_CSP_IDENTITY');
 return {releaseId,inputIdentity:{id:record.input.id,manifestSha256:record.input.manifestSha256},files:rows,techCsp:record.techCsp,techEmbedCsp:record.techEmbedCsp??null,fieldEmbedCsp:record.fieldEmbedCsp??null,demos};
}
export function prepare(releaseRoot,releaseId){
 const verified=spawnSync(process.execPath,[path.join(root,'verify-package.mjs')],{encoding:'utf8',windowsHide:true});
 assert.equal(verified.status,0,'INPUT_PACKAGE_INVALID '+verified.stderr+verified.stdout);
 const manifest=fs.readFileSync(path.join(root,'FILES.sha256'),'utf8'),versionIndex=fs.readFileSync(path.join(root,'VERSION-INDEX.json'),'utf8');
 const record={schemaVersion:1,releaseId:id(releaseId),input:{id:JSON.parse(versionIndex).id,manifestSha256:hash(Buffer.from(manifest)),manifest,versionIndex},files:siteRows(manifestRows(manifest)),techCsp:JSON.parse(fs.readFileSync(path.join(root,'demos/tech/site/CSP.json'))).policy};
 if(record.files.some(row=>row.file.startsWith('tech-embed/')))record.techEmbedCsp=JSON.parse(fs.readFileSync(path.join(root,'demos/tech-embed/site/CSP.json'))).policy;
 if(record.files.some(row=>row.file.startsWith('field-embed/')))record.fieldEmbedCsp=JSON.parse(fs.readFileSync(path.join(root,'demos/field-embed/site/CSP.json'))).policy;
 fs.mkdirSync(releaseRoot,{recursive:true});
 const target=path.resolve(releaseRoot,id(releaseId));
 assert.ok(!fs.existsSync(recordPath(releaseRoot,releaseId)),'RELEASE_RECORD_EXISTS');
 fs.mkdirSync(target); // Existing, empty or partial destinations are never reused.
 for(const demo of [...new Set(record.files.map(row=>row.file.split('/')[0]))])fs.cpSync(path.join(root,'demos',demo,'site'),path.join(target,demo),{recursive:true,errorOnExist:true,force:false});
 fs.mkdirSync(path.dirname(recordPath(releaseRoot,releaseId)),{recursive:true});
 fs.writeFileSync(recordPath(releaseRoot,releaseId),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
 return verifyRelease(releaseRoot,releaseId);
}
export function configuration({address,admin='127.0.0.1:2019',releaseRoot,approved,active=null,local=false}){
 assert.ok(Array.isArray(approved)&&approved.length&&new Set(approved).size===approved.length,'APPROVED_REQUIRED');
 assert.ok(active===null||approved.includes(active),'ACTIVE_NOT_APPROVED');
 assert.match(admin,/^127\.0\.0\.1:\d+$/,'LOCAL_ADMIN_REQUIRED');
 assert.ok(local?/^http:\/\/127\.0\.0\.1:\d+$/.test(address):/^[a-zA-Z0-9][a-zA-Z0-9.-]+$/.test(address),'HOST_REQUIRED');
 const releases=new Map(approved.map(release=>[release,verifyRelease(releaseRoot,release)]));
 const q=s=>JSON.stringify(s.replaceAll('\\','/'));
 const text=['{',` admin ${admin}`,' persist_config off',...(local?[' auto_https off']:[]),'}',`${address} {`,...(local?[' bind 127.0.0.1']:[]),' header Cache-Control "no-store"'];
 for(const [ext,mime] of Object.entries({html:'text/html; charset=utf-8',js:'text/javascript',css:'text/css',svg:'image/svg+xml',png:'image/png',woff2:'font/woff2',webmanifest:'application/manifest+json',json:'application/json',csv:'text/csv',txt:'text/plain',md:'text/plain',sha256:'text/plain'}))text.push(` @mime_${ext} path *.${ext}`,` header @mime_${ext} Content-Type ${q(mime)}`);
 text.push(' @tech_license path /_releases/*/tech/LICENSES/*',' header @tech_license Content-Type "text/plain; charset=utf-8"');
 if(active){
  text.push(' redir /demos/field /demos/field/ 308',' redir /demos/tech /demos/tech/ 308',` redir /demos/field/ /_releases/${active}/field/field-miner-mobile-v01/field-entry-exit-trial.html 302`);
  for(const demo of ['field','tech'])text.push(` handle_path /demos/${demo}/* {`,`  redir * /_releases/${active}/${demo}{uri} 302`,' }');
 }
 for(const release of approved)for(const demo of releases.get(release).demos){
  text.push(` redir /_releases/${release}/${demo} /_releases/${release}/${demo}/ 308`,` handle_path /_releases/${release}/${demo}/* {`,`  root * ${q(path.resolve(releaseRoot,release,demo))}`);
  if(demo==='tech')text.push(`  header Content-Security-Policy ${q(releases.get(release).techCsp)}`);
  if(demo==='tech-embed')text.push(`  header Content-Security-Policy ${q(releases.get(release).techEmbedCsp)}`);
  if(demo==='field-embed')text.push(`  header Content-Security-Policy ${q(releases.get(release).fieldEmbedCsp)}`);
  text.push('  file_server',' }');
 }
 text.push(' handle {','  respond "Not found" 404',' }','}','');return text.join('\n');
}
export async function verifyAliases(origin,releaseId){
 id(releaseId);const rows=[];
 for(const [alias,target] of [
  ['/demos/field/',`/_releases/${releaseId}/field/field-miner-mobile-v01/field-entry-exit-trial.html`],
  ['/demos/field/field-miner-landscape-simple-guide-v01/',`/_releases/${releaseId}/field/field-miner-landscape-simple-guide-v01/`],
  ['/demos/tech/',`/_releases/${releaseId}/tech/`]]){
  const r=await fetch(new URL(alias,origin),{redirect:'manual',signal:AbortSignal.timeout(20000)});
  const row={alias,status:r.status,location:r.headers.get('location'),cache:r.headers.get('cache-control')};rows.push(row);await r.body?.cancel();
  assert.equal(row.status,302,'ALIAS_STATUS');assert.equal(row.location,target,'ALIAS_LOCATION');assert.equal(row.cache,'no-store','ALIAS_CACHE');
 }return rows;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [mode,...args]=process.argv.slice(2);
 if(mode==='prepare'||mode==='verify')console.log(JSON.stringify((mode==='prepare'?prepare:verifyRelease)(...args),null,2));
 else if(mode==='config'){
  const config=configuration(JSON.parse(fs.readFileSync(args[0])));
  fs.writeFileSync(args[1],config,{flag:'wx'});console.log('CONFIG_WRITTEN '+args[1]);
 }else if(mode==='aliases')console.log(JSON.stringify(await verifyAliases(...args),null,2));
 else throw Error('Use prepare|verify RELEASE_ROOT RELEASE_ID, config SPEC_JSON NEW_CADDYFILE, aliases ORIGIN RELEASE_ID');
}
