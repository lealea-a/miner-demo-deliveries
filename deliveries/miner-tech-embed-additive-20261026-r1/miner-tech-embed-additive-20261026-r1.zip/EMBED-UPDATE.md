# Tech 专用 iframe 入口增量候选

此包基于冻结 r4-fix1，新增 `demos/tech-embed/site/`。原 `demos/tech/site/`、`demos/field/site/` 及原首页 CSP 全部保持原字节。未推送 GitHub、未部署公网，不能代替第三方发布回执。

新版本 ID：`release-tech-embed-20261026-r1`。新入口是：

`https://tech.ektopod.cn/_releases/release-tech-embed-20261026-r1/tech-embed/embed.html`

该 URL 只有部署方实际挂载此路径并通过 HTTP 核验后才成立。现有公开站点响应为 openresty；不能仅凭此判断它是否代理已有 Caddy。部署方应使用其原发布通路暴露上述新路径。以下命令复用本包已有 Caddy release 工具，不是向未知 openresty 控制面自动发布。

## 现有 release 并列更新

在本包解压根目录运行，沿用部署方实际的 releaseRoot 与当前配置。以下 `C:/Miner/releases` 是原交付示例；若现场不同，替换为原有目录，不新建另一套站点。

```powershell
node verify-package.mjs
node deploy/release.mjs prepare C:/Miner/releases release-tech-embed-20261026-r1
node deploy/release.mjs verify C:/Miner/releases release-tech-embed-20261026-r1
```

复制现场当前配置为 `C:/Miner/embed-stage.json`，仅向 `approved` 数组追加 `release-tech-embed-20261026-r1`；`active`、address、admin、releaseRoot 均保留现场原值。不要切换 active，不覆盖旧 release，不修改旧域名根入口。示例中原 active 为 release-A 时，approved 为 `["release-A","release-tech-embed-20261026-r1"]`，active 仍为 `"release-A"`。

```powershell
node deploy/release.mjs config C:/Miner/embed-stage.json C:/Miner/embed-stage.caddy
caddy validate --config C:/Miner/embed-stage.caddy --adapter caddyfile
caddy reload --address 127.0.0.1:2019 --config C:/Miner/embed-stage.caddy --adapter caddyfile
node deploy/verify-embed.mjs https://tech.ektopod.cn/_releases/release-tech-embed-20261026-r1/tech-embed/
```

命令均需成功后再继续。若现场 admin 地址不同，沿用原地址。原 `UPDATE-ROLLBACK.md` 的配置持久化流程仍适用；不要把仅一次 reload 当成已保存启动配置。

部署方回传：实际新入口 URL、HTTP核验 JSON、实际加载配置/版本、旧 Tech 首页与 Field 地址未变的核验结果。随后 Worker 才能把隔离父 Runtime 的专用 URL 切到已核公网地址，并运行真实 iframe 链路。当前父 4542 仍引用本地子 4543。

## 每路径 CSP 与来源

`deploy/release.mjs` 对新版本中的 `tech-embed` 路径单独设置 `demos/tech-embed/site/CSP.json` 的 HTTP 头；不使用 meta 替代。旧 Tech 继续使用其原 CSP，Field 不增加这条策略。

允许的父 origin 仅有：

- `http://127.0.0.1:4542`：本批隔离 Runtime。
- `http://127.0.0.1:4544`：本批受控测试入口。
- `https://ekto-pod-d4gvyzlwhb97709b9-1472892036.tcloudbaseapp.com`：已有 H5 公网 origin；本批未发布或验收该公网父页。

桥接代码使用同一明确允许列表，并验证父窗口、session、build 与命令 revision；没有通配 targetOrigin。若第三方在不同父 origin 部署，必须先提供真实 origin 供明确更新，不能放开所有来源。

专用入口直接打开会显示父来源拒绝，这是预期。它通过父 iframe query 接收 session/build/parent_origin，不能用直接打开入口是否能交互代替 iframe 验收。

## 保留与回退

此阶段不切换 `/demos/tech/`、`/demos/field/` 别名，所以原 active 不变。发现异常时恢复之前保存的配置并验证原入口即可；保留新版本目录，不覆盖/删除旧版本，不清浏览器业务存储。

本地两引擎真实 iframe 进退通过不等于公网通过。WebKit 尺寸变化后画面近空白仍保留待验；原组件也能复现，缓冲区有内容不能签视觉通过。实体手机、真实后台与公网父域尚未验收。
