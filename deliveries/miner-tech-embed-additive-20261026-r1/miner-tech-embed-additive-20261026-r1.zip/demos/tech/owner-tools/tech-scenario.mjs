import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
export function selectionState(snapshot){
 if(snapshot?.phase!=='INNER'||snapshot?.lastErrorMessage||!['PROMPT','FOCUSING','ACTIVE'].includes(snapshot?.inner?.state))throw Error('PICK_UNEXPECTED_STATE:'+JSON.stringify({phase:snapshot?.phase??null,state:snapshot?.inner?.state??null,error:snapshot?.lastErrorMessage??null}));
 return snapshot.inner.state;
}
export async function selectCandidate(page,out,layout,budget){
 const record={status:'FAIL',clicks:[],stopState:null,active:false};
 const snapshot=()=>page.evaluate(()=>window.__TECH_MINER_EXPERIENCE__?.snapshot?.()??null);
 try{
  assert.equal(selectionState(await snapshot()),'PROMPT','PICK_REQUIRES_STABLE_PROMPT');
  const r=await page.locator('[data-role=scene] canvas').boundingBox(),points=[];assert.ok(r,'CANVAS_MISSING');
  for(let y=16;y<r.height;y+=32)for(let x=16;x<r.width;x+=32)points.push({x:x+r.x,y:y+r.y,d:Math.hypot(x-r.width/2,y-r.height/2)});points.sort((a,b)=>a.d-b.d);
  for(const p of points){
   budget.check('candidate-pick');const before=selectionState(await snapshot());
   if(before==='FOCUSING'||before==='ACTIVE'){record.stopState=before;break;}
   await page.mouse.click(p.x,p.y);const after=selectionState(await snapshot());record.clicks.push({x:p.x,y:p.y,before,after});
   if(after==='FOCUSING'||after==='ACTIVE'){record.stopState=after;break;}
  }
  assert.ok(record.stopState,'PICK_CANDIDATES_EXHAUSTED');
  await page.waitForFunction(()=>{const s=window.__TECH_MINER_EXPERIENCE__?.snapshot?.();if(s?.phase!=='INNER'||s?.lastErrorMessage||!['FOCUSING','ACTIVE'].includes(s?.inner?.state))throw Error('PICK_WAIT_UNEXPECTED_STATE:'+JSON.stringify({phase:s?.phase??null,state:s?.inner?.state??null,error:s?.lastErrorMessage??null}));return s.inner.state==='ACTIVE';});
  await page.evaluate(()=>__TECH_MINER_EXPERIENCE__.whenSettled());assert.equal(selectionState(await snapshot()),'ACTIVE');budget.check('after-pick-active');record.active=true;record.status='PASS';return record;
 }catch(error){record.error=String(error.stack);throw error;}finally{fs.writeFileSync(path.join(out,layout+'-picker.json'),JSON.stringify(record,null,2));}
}
export async function techScenario(page,base,out,layout,budget,checkNavigation){
 assert.equal(typeof checkNavigation,'function','NAVIGATION_CHECK_REQUIRED');
 const response=await page.goto(base.href,{waitUntil:'domcontentloaded'});budget.check('after-navigation');await checkNavigation(response,page);
 if(await page.getByRole('button',{name:/^确定访问/}).count())throw Error('OWNER_HANDOFF_PLATFORM_INTERSTITIAL');
 await page.waitForFunction(()=>window.__TECH_MINER_EXPERIENCE__);await page.evaluate(()=>__TECH_MINER_EXPERIENCE__.whenSettled());
 assert.equal(await page.evaluate(()=>__TECH_MINER_EXPERIENCE__.snapshot().phase),'ENTRY');await page.screenshot({path:path.join(out,layout+'-cover.png')});
 await page.locator('[data-role=entry-enter]').click();await page.waitForFunction(()=>__TECH_MINER_EXPERIENCE__.snapshot().phase==='INNER');await page.evaluate(()=>__TECH_MINER_EXPERIENCE__.whenSettled());budget.check('after-enter');
 const selection=await selectCandidate(page,out,layout,budget);await page.screenshot({path:path.join(out,layout+'-card.png')});
 const card=page.locator('.card-overlay.is-visible');await card.locator('[data-card-section=condition]').click();await card.locator('[data-card-page="6"]').click();await page.waitForFunction(()=>__TECH_MINER_EXPERIENCE__.getState().runtimeState.cardPage===6);await page.evaluate(()=>__TECH_MINER_EXPERIENCE__.whenSettled());
 const before=await page.evaluate(()=>__TECH_MINER_EXPERIENCE__.getState());await card.locator('.card-trial-cue').click();await page.waitForFunction(()=>document.querySelector('dialog[open]')?.hasAttribute('data-positioned'));await page.screenshot({path:path.join(out,layout+'-trial.png')});
 await page.locator('dialog[open] .trial-bridge__connect').click();await page.locator('.trial-bridge__qr-return').waitFor({state:'visible'});await page.locator('.trial-bridge__qr-return').click();assert.deepEqual(await page.evaluate(()=>__TECH_MINER_EXPERIENCE__.getState()),before,'RETURN_STATE_CHANGED');budget.check('after-trial-return');return {selection,trialQrReturn:true};
}
