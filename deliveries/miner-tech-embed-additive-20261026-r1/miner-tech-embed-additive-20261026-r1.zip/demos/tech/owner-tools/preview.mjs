import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {root,verifySite} from './config.mjs';
verifySite();
const port=Number(process.argv[2]||5234);
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.txt':'text/plain; charset=utf-8'};
const policy=JSON.parse(fs.readFileSync(path.join(root,'site/CSP.json'))).policy;
http.createServer((req,res)=>{try{let name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(name.endsWith('/'))name+='index.html';const p=path.resolve(root,'.'+name);if(!p.startsWith(root+path.sep)||!fs.existsSync(p)||!fs.statSync(p).isFile()){res.writeHead(404);res.end('Not found');return;}res.setHeader('Content-Type',mime[path.extname(p)]||'application/octet-stream');res.setHeader('Cache-Control','no-cache');if(p.startsWith(path.join(root,'site')+path.sep))res.setHeader('Content-Security-Policy',policy);res.end(fs.readFileSync(p));}catch{res.writeHead(400);res.end('Bad request');}}).listen(port,'127.0.0.1',()=>console.log(`Owner guide: http://127.0.0.1:${port}/owner-guide/ ; exact site: http://127.0.0.1:${port}/site/`));
