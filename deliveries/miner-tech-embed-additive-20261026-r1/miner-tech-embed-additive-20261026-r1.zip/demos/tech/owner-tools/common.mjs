import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';

export const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const site = path.join(root, 'site');
export const require = createRequire(path.join(root, 'package.json'));
export const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
export function prerequisites() {
  if (process.platform !== 'win32' || process.arch !== 'x64' || process.versions.node !== '24.21.0') {
    throw Error('Requires Windows 11 x64 and Node.js 24.21.0; current ' + process.platform + '/' + process.arch + '/' + process.versions.node);
  }
}
export function environment() {
  const env = {...process.env};
  for (const k of Object.keys(env)) {
    if (/^npm_config_/i.test(k) || ['NODE_PATH', 'NODE_OPTIONS', 'TECH_RESEARCH_CHROMIUM'].includes(k)) delete env[k];
  }
  const cache = path.join(root, '.owner-cache');
  fs.mkdirSync(cache, {recursive: true});
  for (const f of ['empty-user.npmrc', 'empty-global.npmrc']) fs.writeFileSync(path.join(cache, f), '');
  return {...env, PATH: path.dirname(process.execPath) + path.delimiter + (env.PATH || env.Path || ''),
    NODE_PATH: '', NODE_OPTIONS: '', npm_config_userconfig: path.join(cache, 'empty-user.npmrc'),
    npm_config_globalconfig: path.join(cache, 'empty-global.npmrc'), npm_config_cache: path.join(cache, 'npm'),
    npm_config_registry: 'https://registry.npmjs.org/', PLAYWRIGHT_BROWSERS_PATH: path.join(root, '.owner-browsers')};
}
function within(base, target) {
  const relative = path.relative(base, target);
  return relative !== '' && !relative.startsWith('..' + path.sep) && relative !== '..' && !path.isAbsolute(relative);
}
// A package root can be supplied for isolated resolution fixtures. No global-directory assumptions.
export function resolveLocalDependency(name, packageRoot = root) {
  const realRoot = fs.realpathSync(packageRoot);
  const localModules = path.join(realRoot, 'node_modules');
  const resolved = createRequire(path.join(packageRoot, 'package.json')).resolve(name);
  const expected=JSON.parse(fs.readFileSync(path.join(packageRoot,'package.json'))).dependencies[name];
  if(JSON.parse(fs.readFileSync(path.join(localModules,name,'package.json'))).version!==expected)throw Error('DEPENDENCY_VERSION_MISMATCH '+name);
  if (!within(localModules, resolved)) throw Error('DEPENDENCY_OUTSIDE_PACKAGE ' + name);
  const realModules = fs.realpathSync(localModules);
  const realResolved = fs.realpathSync(resolved);
  if (!within(realRoot, realModules) || !within(realModules, realResolved)) {
    throw Error('DEPENDENCY_OUTSIDE_PACKAGE_REALPATH ' + name);
  }
  return realResolved;
}
export const dependency = name => resolveLocalDependency(name);
export function runNode(args, {cwd = root, env = environment(), log, echo = true} = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, args, {cwd, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe']});
    let stdout = '', stderr = '';
    child.stdout.on('data', b => {stdout += b; if (echo) process.stdout.write(b);});
    child.stderr.on('data', b => {stderr += b; if (echo) process.stderr.write(b);});
    child.on('error', reject);
    child.on('close', code => {
      if (log) fs.writeFileSync(log, JSON.stringify({executable: process.execPath, args, exitCode: code, stdout, stderr}, null, 2));
      if (code !== 0) reject(Object.assign(Error('Command failed (' + code + '): ' + args[0]), {exitCode: code, stdout, stderr}));
      else resolve({stdout, stderr, exitCode: code});
    });
  });
}
export function freshRun(label, output = path.join(root,'output')) {
  const d = path.join(output, label + '-' + new Date().toISOString().replace(/[:.]/g, '-') + '-' + crypto.randomUUID().slice(0,8));
  fs.mkdirSync(d, {recursive: true});
  return d;
}
export function browserInfo() {
  process.env.PLAYWRIGHT_BROWSERS_PATH = path.join(root, '.owner-browsers');
  dependency('playwright');
  const {chromium} = require('playwright');
  const executable = chromium.executablePath();
  if (!fs.existsSync(executable) || !within(fs.realpathSync(root), fs.realpathSync(executable)) ||
      !within(fs.realpathSync(path.join(root, '.owner-browsers')), fs.realpathSync(executable))) {
    throw Error('Project browser missing or outside package; run npm.cmd run setup');
  }
  return {chromium, executable};
}
