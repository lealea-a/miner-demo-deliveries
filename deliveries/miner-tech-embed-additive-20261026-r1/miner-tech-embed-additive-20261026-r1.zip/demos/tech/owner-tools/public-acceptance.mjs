import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {performance} from 'node:perf_hooks';
import {root,sha,verifySite} from './config.mjs';import {browserInfo} from './common.mjs';import {techScenario} from './tech-scenario.mjs';
const MIME = {
  '.html':['text/html'], '.js':['text/javascript','application/javascript'], '.css':['text/css'],
  '.svg':['image/svg+xml'], '.png':['image/png'], '.woff2':['font/woff2','application/font-woff2'],
  '.json':['application/json'], '.webmanifest':['application/manifest+json','application/json'],
  '.csv':['text/csv','text/plain','application/octet-stream'], '.txt':['text/plain','application/octet-stream'],
  '.md':['text/plain','text/markdown','application/octet-stream'], '.sha256':['text/plain','application/octet-stream']
};
// Explicit list generated from the frozen package's UTF-8 LICENSE/NOTICE files.
const TEXT_LICENSE_FILES=new Set(JSON.parse(fs.readFileSync(path.join(root,'owner-tools/text-license-files.json'),'utf8')));
export const allowedMime=file=>TEXT_LICENSE_FILES.has(file)?['text/plain','application/octet-stream']:(MIME[path.extname(file)]||['application/octet-stream']);

export function checkCache(headers,file){
 assert.ok(headers['cache-control'],'CACHE_CONTROL_MISSING');
 if(['index.html','CSP.json','FILES.sha256','RELEASE_MANIFEST.json'].includes(file)){
  for(const name of ['cache-control','cdn-cache-control','surrogate-control']){
   if(!headers[name])continue;const fields=headers[name].toLowerCase().split(/,(?=(?:[^"]*"[^"]*")*[^"]*$)/).map(s=>s.trim());
   assert.ok(!fields.some(s=>/^immutable(?:=|$)/.test(s)),'CACHE_IMMUTABLE_METADATA');
   for(const key of ['max-age','s-maxage','stale-while-revalidate','stale-if-error']){const entries=fields.filter(s=>s.split('=')[0].trim()===key);assert.ok(entries.length<=1,'CACHE_DUPLICATE_TTL');for(const entry of entries)assert.match(entry,new RegExp('^'+key+'=\\s*"?0"?$'),'CACHE_POSITIVE_TTL');}
   assert.ok(fields.includes('no-cache')||fields.includes('no-store')||(fields.some(s=>/^max-age=\s*"?0"?$/.test(s))&&fields.includes('must-revalidate')),'METADATA_REVALIDATION_REQUIRED');
  }
  if(headers.expires&&headers.date)assert.ok(!Number.isFinite(Date.parse(headers.expires))||Date.parse(headers.expires)<=Date.parse(headers.date),'CACHE_FUTURE_EXPIRES');
 }
}
export async function responseEvidence(file, expectedSha256, base, out, overallSignal, policy) {
  const requested = new URL(file, base).href;
  const row = {file, requestedUrl:requested, expectedSha256, hops:[], pass:false};
  try {
    let url = requested, response;
    for (let hop = 0; hop < 5; hop++) {
      response = await fetch(url, {redirect:'manual', signal:overallSignal ? AbortSignal.any([overallSignal, AbortSignal.timeout(20000)]) : AbortSignal.timeout(20000)});
      const headers = Object.fromEntries([...response.headers].filter(([key]) => key !== 'set-cookie'));
      row.hops.push({url, status:response.status, headers});
      if (response.status >= 300 && response.status < 400) {
        const location = response.headers.get('location');
        assert.ok(location, 'REDIRECT_WITHOUT_LOCATION');
        const next = new URL(location, url);
        assert.ok(next.origin === base.origin && next.pathname.startsWith(base.pathname) && !next.search && !next.hash, 'REDIRECT_OUTSIDE_TARGET');
        await response.body?.cancel();
        url = next.href;
        if (hop === 4) throw Error('REDIRECT_LIMIT');
        continue;
      }
      break;
    }
    row.actualUrl = response.url;
    row.status = response.status;
    row.headers = row.hops.at(-1).headers;
    const bytes = Buffer.from(await response.arrayBuffer());
    row.bytes = bytes.length;
    row.actualSha256 = sha(bytes);
    const bodyPath = path.join(out, 'responses', file);
    fs.mkdirSync(path.dirname(bodyPath), {recursive:true});
    fs.writeFileSync(bodyPath, bytes);
    row.body = 'responses/' + file;
    assert.equal(row.status, 200, 'HTTP_STATUS');
    assert.equal(row.actualUrl, requested, 'UNEXPECTED_FINAL_URL');
    const mime = (row.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    assert.ok(allowedMime(file).includes(mime), 'MIME_MISMATCH ' + mime);
    assert.equal(row.actualSha256, expectedSha256, 'SHA_MISMATCH');
    // Existing names are not guaranteed content-addressed; all files use conservative revalidation.
    checkCache(row.headers, file);
    if(file==='index.html')assert.equal(row.headers['content-security-policy'],policy,'CSP_MISMATCH');
    row.pass = true;
  } catch (error) {
    row.error = String(error.stack);
    row.cause = error.cause ? String(error.cause) : null;
  }
  return row;
}

export async function navigationEvidence(response,page,base,out,layout,row){
 Object.assign(row,{requestedUrl:base.href,pass:false,hops:[]});
 try{
  assert.ok(response,'NAVIGATION_RESPONSE_MISSING');
  const requests=[];for(let request=response.request();request;request=request.redirectedFrom()){requests.unshift(request);assert.ok(requests.length<=6,'NAVIGATION_REDIRECT_LIMIT');}
  for(const request of requests){const r=await request.response(),headers=r?Object.fromEntries(Object.entries(await r.allHeaders()).filter(([key])=>key!=='set-cookie')):{};row.hops.push({url:request.url(),status:r?.status()??null,headers});}
  row.actualUrl=response.url();row.pageUrl=page.url();row.status=response.status();row.headers=Object.fromEntries(Object.entries(await response.allHeaders()).filter(([key])=>key!=='set-cookie'));
  const bytes=await response.body();row.bytes=bytes.length;row.actualSha256=sha(bytes);row.expectedSha256=sha(fs.readFileSync(path.join(root,'site/index.html')));row.body=layout+'-entry-body.html';fs.writeFileSync(path.join(out,row.body),bytes);
  for(const hop of row.hops){const u=new URL(hop.url);assert.ok(u.origin===base.origin&&u.pathname.startsWith(base.pathname)&&!u.search&&!u.hash,'NAVIGATION_REDIRECT_OUTSIDE_TARGET');}
  assert.equal(row.hops[0]?.url,base.href,'NAVIGATION_INITIAL_URL_MISMATCH');assert.equal(row.status,200,'NAVIGATION_HTTP_STATUS');assert.equal(row.actualUrl,base.href,'NAVIGATION_FINAL_URL_MISMATCH');assert.equal(row.pageUrl,base.href,'BROWSER_TARGET_MISMATCH');
  assert.equal(row.actualSha256,row.expectedSha256,'NAVIGATION_SHA_MISMATCH');assert.ok(allowedMime('index.html').includes((row.headers['content-type']||'').split(';')[0].trim().toLowerCase()),'NAVIGATION_MIME_MISMATCH');
  assert.equal(row.headers['content-security-policy'],JSON.parse(fs.readFileSync(path.join(root,'site/CSP.json'))).policy,'NAVIGATION_CSP_MISMATCH');checkCache(row.headers,'index.html');row.pass=true;return row;
 }catch(error){row.error=String(error.stack);throw error;}finally{fs.writeFileSync(path.join(out,layout+'-entry-response.json'),JSON.stringify(row,null,2));}
}
function cleanLog(value){return String(value??'').replace(/https?:\/\/[^\s)"']+/g,s=>{try{const u=new URL(s);return u.origin+u.pathname}catch{return '[URL]'}}).slice(0,4000);}
export function acceptanceBudget({timeoutMs = 180000, signal, now = () => performance.now(), onBoundary} = {}) {
  assert.ok(Number.isInteger(timeoutMs) && timeoutMs > 0, 'POSITIVE_TOTAL_BUDGET_REQUIRED');
  const started = now(), deadline = started + timeoutMs;
  const timerSignal = AbortSignal.timeout(timeoutMs);
  const combined = signal ? AbortSignal.any([timerSignal, signal]) : timerSignal;
  const events = [];
  return {
    signal:combined, timeoutMs, events,
    elapsed:() => now() - started,
    expired:() => combined.aborted || now() >= deadline,
    check(stage) {
      onBoundary?.(stage);
      const remainingMs = deadline - now();
      events.push({stage, elapsedMs:now()-started, remainingMs, aborted:combined.aborted});
      combined.throwIfAborted();
      if (remainingMs <= 0) throw new DOMException('Total acceptance deadline exceeded at ' + stage, 'TimeoutError');
      return remainingMs;
    }
  };
}

export async function browserAcceptance(base, out, budget, launchOverride, infoOverride) {
  const signal = budget.signal;
  const rows = [], ownership = {launched:false, closeRequested:false, closed:false};
  let browser, closing, listenerRegistered = false, primaryError;
  // The abort callback observes rejection immediately; finally awaits the same close operation.
  const closeOwnedBrowser = () => {
    if (!closing) {
      ownership.closeRequested = true;
      closing = Promise.resolve().then(() => browser.close());
      closing.catch(() => {});
    }
    return closing;
  };
  const abort = () => {closeOwnedBrowser();};
  try {
    budget.check('before-browser-info');
    const {chromium, executable} = infoOverride ? infoOverride() : browserInfo();
    ownership.executable = executable;
    ownership.launchRemainingMs = budget.check('before-launch');
    const launchTimeout = Math.floor(ownership.launchRemainingMs);
    if (launchTimeout < 1) throw new DOMException('No positive launch budget remains', 'TimeoutError');
    ownership.launchTimeoutMs = launchTimeout;
    const launch = launchOverride || (options => chromium.launch(options));
    // Await directly: a late result is still owned by this finally; no losing Promise.race result.
    browser = await launch({headless:true, executablePath:executable, timeout:launchTimeout});
    ownership.launched = true;
    budget.check('after-launch');
    budget.check('before-abort-listener');
    signal.addEventListener('abort', abort, {once:true});
    listenerRegistered = true;
    budget.check('after-abort-listener');
    for (const portrait of [true,false]) {
      const layout=portrait?'portrait':'landscape';budget.check('before-'+layout);
      const context=await browser.newContext({viewport:portrait?{width:390,height:844}:{width:1280,height:720}});
      budget.check('after-context');const page=await context.newPage();budget.check('after-page');page.setDefaultTimeout(Math.min(25000,budget.check('page-timeout')));
      const row={layout,url:base.href,errors:[],warnings:[],requestFailures:[],failedResponses:[],pass:false};
      page.on('pageerror',e=>row.errors.push(cleanLog(e.message)));
      page.on('console',m=>{if(m.type()==='error')row.errors.push(cleanLog(m.text()));else if(m.type()==='warning')row.warnings.push(cleanLog(m.text()));});
      page.on('requestfailed',r=>row.requestFailures.push({url:cleanLog(r.url()),error:cleanLog(r.failure()?.errorText)}));
      page.on('response',r=>{if(r.status()>=400)row.failedResponses.push({url:cleanLog(r.url()),status:r.status()});});
      try {
        row.entry={};row.scenario=await techScenario(page,base,out,layout,budget,(response,page)=>navigationEvidence(response,page,base,out,layout,row.entry));
        assert.deepEqual(row.errors,[],'BROWSER_ERRORS');assert.deepEqual(row.requestFailures,[],'REQUEST_FAILURES');assert.deepEqual(row.failedResponses,[],'HTTP_ERRORS');
        budget.check('before-'+layout+'-pass');row.pass=true;
      }catch(error){row.error=cleanLog(error.stack);await page.screenshot({path:path.join(out,layout+'-failure.png')}).catch(()=>{});}
      finally{rows.push(row);fs.writeFileSync(path.join(out,'browser.json'),JSON.stringify({engine:'local headless Chromium, not cloud real-device evidence',version:browser.version(),rows},null,2));await context.close();}
      budget.check('after-'+layout);
    }
    budget.check('after-browser-layouts');
  } catch (error) {
    primaryError = error;
    throw error;
  } finally {
    if (listenerRegistered) signal.removeEventListener('abort', abort);
    try {
      if (browser) {
        await closeOwnedBrowser();
        ownership.closed = true;
        ownership.connectedAfterClose = browser.isConnected();
      }
    } catch (cleanupError) {
      ownership.cleanupError = String(cleanupError.stack);
      if (primaryError) throw new AggregateError([primaryError, cleanupError], 'Acceptance and browser cleanup failed');
      throw cleanupError;
    } finally {
      fs.writeFileSync(path.join(out,'browser-ownership.json'), JSON.stringify(ownership, null, 2));
    }
  }
  return rows;
}

export function checkMissing(status,bytes,indexBytes){return status===404&&sha(bytes)!==sha(indexBytes)&&!bytes.toString().includes('data-tech-miner');}
export async function checkDirectory(base,signal){
 assert.ok(base.pathname.endsWith('/'),'DIRECTORY_SLASH_REQUIRED');
 const url=base.href.slice(0,-1),r=await fetch(url,{redirect:'manual',signal});
 const row={url,status:r.status,location:r.headers.get('location'),pass:false};await r.body?.cancel();
 row.pass=[301,302,307,308].includes(row.status)&&new URL(row.location||'__missing',url).href===base.href;return row;
}
export async function verifyPublic(config,out){
 const budget=acceptanceBudget();fs.mkdirSync(out,{recursive:true});const result={status:'FAIL',at:new Date().toISOString(),files:[],browsers:[],totalTimeoutMs:180000,scope:'Owner public HTTP identity plus local headless Chromium; not manual acceptance'};
 try{budget.check('entry');const verified=verifySite(),base=new URL(config.base),policy=JSON.parse(fs.readFileSync(path.join(root,'site/CSP.json'))).policy;result.base=base.href;
  for(const item of verified.rows){budget.check('before-http');result.files.push(await responseEvidence(item.path,item.sha256,base,out,budget.signal,policy));fs.writeFileSync(path.join(out,'http.json'),JSON.stringify(result.files,null,2));}
  budget.check('before-404');const url=new URL('__r10_missing_'+Date.now()+'.js',base),r=await fetch(url,{redirect:'manual',signal:AbortSignal.any([budget.signal,AbortSignal.timeout(20000)])}),bytes=Buffer.from(await r.arrayBuffer());result.missing={url:url.href,status:r.status,sha256:sha(bytes),pass:checkMissing(r.status,bytes,fs.readFileSync(path.join(root,'site/index.html')))};
  budget.check('before-directory');result.directory=await checkDirectory(base,budget.signal);
  result.browsers=await browserAcceptance(base,out,budget);assert.equal(result.files.length,124);assert.ok(result.files.every(r=>r.pass),'PUBLIC_HTTP_ACCEPTANCE_FAILED');assert.ok(result.directory.pass,'DIRECTORY_REDIRECT_REQUIRED');assert.ok(result.missing.pass,'MISSING_ASSET_NOT_404');assert.equal(result.browsers.length,2);assert.ok(result.browsers.every(r=>r.pass),'PUBLIC_BROWSER_ACCEPTANCE_FAILED');budget.check('before-final-pass');result.status='PASS';return result;
 }catch(error){result.error=String(error.stack);throw Error('PUBLIC_ACCEPTANCE_FAILED: '+error.message,{cause:error});}
 finally{result.elapsedMs=budget.elapsed();result.budgetChecks=budget.events;fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify(result,null,2));}
}
