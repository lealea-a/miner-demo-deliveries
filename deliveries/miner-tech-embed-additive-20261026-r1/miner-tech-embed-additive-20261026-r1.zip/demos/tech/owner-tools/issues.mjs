import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';import {root} from './config.mjs';
export function validate(r){
 const current=JSON.parse(fs.readFileSync(path.join(root,'R10-IDENTITY.json')));
 assert.equal(r.schemaVersion,1);assert.ok(['UNASSESSED','OPEN','IN_PROGRESS','RESOLVED','NOT_REPRODUCED'].includes(r.status),'STATUS');assert.equal(r.candidateVersion,'R10');
 for(const key of ['filesSha256','siteZipSha256','engineeringZipSha256']){
  assert.match(r.identity?.[key]||'',/^[A-Fa-f0-9]{64}$/,'HASH '+key);
  assert.equal(r.identity[key].toLowerCase(),current[key].toLowerCase(),'IDENTITY_MISMATCH '+key);
 }
 assert.ok(r.environment&&typeof r.environment==='object');
 for(const k of ['device','os','browser','browserVersion','url','extensions'])assert.ok(Object.hasOwn(r.environment,k),'ENVIRONMENT '+k);
 assert.ok(Array.isArray(r.reproductionSteps)&&r.reproductionSteps.every(x=>typeof x==='string'));
 assert.ok(Array.isArray(r.evidencePaths)&&r.evidencePaths.every(x=>typeof x==='string'));
 for(const k of ['expected','actual','observedAt'])assert.ok(r[k]===null||typeof r[k]==='string');
 assert.ok(r.resolution===null||typeof r.resolution==='string','RESOLUTION_TYPE');
 assert.ok(Array.isArray(r.regressionEvidencePaths)&&r.regressionEvidencePaths.every(x=>typeof x==='string'),'REGRESSION_EVIDENCE_TYPE');
 if(r.status!=='UNASSESSED'){
  assert.ok(r.reproductionSteps.some(x=>x.trim())&&r.expected?.trim()&&r.actual?.trim()&&r.evidencePaths.some(x=>x.trim()),'REPORT_INCOMPLETE');
  assert.ok(typeof r.environment.os==='string'&&r.environment.os.trim()&&typeof r.environment.browser==='string'&&r.environment.browser.trim(),'ENVIRONMENT_INCOMPLETE');
 }
 if(r.status==='RESOLVED'){
  assert.ok(r.resolution?.trim(),'RESOLUTION_FIX_REQUIRED');
  assert.ok(r.regressionEvidencePaths.some(x=>x.trim()),'RESOLUTION_REGRESSION_EVIDENCE_REQUIRED');
 }
 return true;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){for(const file of process.argv.slice(2).length?process.argv.slice(2):['ISSUE-TEMPLATE.json']){validate(JSON.parse(fs.readFileSync(path.resolve(root,file))));console.log('VALID '+file);}}
