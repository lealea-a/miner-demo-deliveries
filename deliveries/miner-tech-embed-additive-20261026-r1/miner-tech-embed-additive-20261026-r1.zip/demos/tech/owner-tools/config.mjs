import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
export const root=path.resolve(import.meta.dirname,'..');
export const sha=b=>createHash('sha256').update(b).digest('hex').toUpperCase();
export function config(file='owner-config.json') {
 const c=JSON.parse(fs.readFileSync(path.resolve(root,file),'utf8'));
 if(c===null||typeof c!=='object'||Array.isArray(c))throw Error('CONFIG_OBJECT_REQUIRED');
 for(const key of ['environmentId','domain','deploymentPrefix','outputDir'])if(typeof c[key]!=='string'||!c[key].length||c[key].trim()!==c[key])throw Error('CONFIG_NONEMPTY_STRING_REQUIRED:'+key);
 if(!/^[a-zA-Z0-9_-]+$/.test(c.environmentId)||c.environmentId.startsWith('REPLACE')) throw Error('Set environmentId');
 const u=new URL(c.domain);
 if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.pathname!=='/'||u.hostname.endsWith('.invalid')) throw Error('domain must be a real HTTPS origin');
 if(!/^[a-zA-Z0-9_-]+(?:\/[a-zA-Z0-9_-]+)*$/.test(c.deploymentPrefix)) throw Error('Use a nonempty versioned deploymentPrefix without leading/trailing slash');
 const output=path.resolve(root,c.outputDir);
 const site=path.join(root,'site');
 const rel=path.relative(root,output),top=rel.split(path.sep)[0];
 if(output===root||(!rel.startsWith('..'+path.sep)&&rel!=='..'&&!path.isAbsolute(rel)&&!['output','owner-output'].includes(top))) throw Error('outputDir must be output/owner-output or outside the package');
 return {...c,site,output,base:new URL(c.deploymentPrefix+'/',u).href};
}
export function verifySite() {
 const site=path.join(root,'site'),manifest=fs.readFileSync(path.join(site,'FILES.sha256'));
 const identity=JSON.parse(fs.readFileSync(path.join(root,'R10-IDENTITY.json')));
 if(sha(manifest)!==identity.filesSha256) throw Error('FILES_IDENTITY_CHANGED');
 const rows=manifest.toString().trim().split(/\r?\n/).map(line=>{const m=/^([A-Fa-f0-9]{64})  (.+)$/.exec(line);if(!m)throw Error('BAD_MANIFEST');return {path:m[2],sha256:m[1].toUpperCase()};});
 rows.push({path:'FILES.sha256',sha256:identity.filesSha256});
 const seen=new Set();
 for(const row of rows){const p=path.resolve(site,row.path);if(!p.startsWith(site+path.sep)||seen.has(row.path))throw Error('BAD_PATH');seen.add(row.path);if(sha(fs.readFileSync(p))!==row.sha256)throw Error('SITE_CHANGED:'+row.path);}
 function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{const p=path.join(dir,e.name);if(e.isSymbolicLink())throw Error('SYMLINK');return e.isDirectory()?walk(p):[path.relative(site,p).replaceAll('\\','/')];});}
 const actual=walk(site);if(actual.length!==rows.length||actual.some(p=>!seen.has(p)))throw Error('FILE_SET_CHANGED');
 return {identity,rows};
}
