import {prerequisites} from './common.mjs';
prerequisites();const i=process.argv.indexOf('--port');const port=i<0?'5234':process.argv[i+1];if(!/^\d+$/.test(port)||Number(port)<1024||Number(port)>65535)throw Error('PORT_1024_TO_65535_REQUIRED');process.argv[2]=port;await import('./preview.mjs');
