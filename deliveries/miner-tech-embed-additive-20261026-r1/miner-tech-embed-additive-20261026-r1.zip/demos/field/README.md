# Field Miner — integrated static delivery

The Playwright-unified Owner input was technically accepted on 2026-10-10. This derived integration requires its own independent final review. SITE-RECORD retains the frozen candidate label and exact bytes; it is not an online acceptance receipt.

Prepare only site/ contents in a new, unrouted version directory, verify it, then switch the stable alias using ../../GETTING-STARTED.md and ../../UPDATE-ROLLBACK.md. Never overwrite a live target. Both layout directories must remain complete, including licenses. See DEPLOYMENT.md for MIME, strict revalidation, real 404, directory redirects, PWA scope and rollback. The static host requires no Node, npm or PowerShell.

Entries under the target:
- field-miner-mobile-v01/field-entry-exit-trial.html
- field-miner-landscape-simple-guide-v01/

Optional local Owner tools retain the accepted Windows 11 x64 / Node 24.21.0 / npm 11.19.0 requirements. No pwsh or PowerShell 7 is required. From this directory, node verify-package.mjs and npm.cmd start require no npm install. Start defaults to owner-field on 127.0.0.1:8781; --port selects a free port. Set owner.config.json from owner.config.example.json for another targetRoot. Diagnostic mode and original full regression commands are not included in this slim deployment delivery.

For issue validation, public verification and optional CloudBase tooling run npm.cmd run setup first. It downloads locked local dependencies and a local Chromium and requires network access. Then npm.cmd run issue:validate, npm.cmd run deploy:plan and npm.cmd run deploy:verify are available with the Owner's configuration. Real upload remains an explicit npm.cmd run deploy -- --confirm-upload action requiring account/hosting approval; none was run here. The retained tools have their original 180000 ms public verification budget. Never upload owner-tools, dependencies, reports or this outer directory.

AI-HANDOFF.md and issue-report.template.json / issue-report.schema.json are the independent support handoff. The Safari example is historical, not a new observation. Full regression/maintenance/history are excluded here; accepted 176/13/33/8 evidence is indexed in ../../VERSION-INDEX.json. Full source is a separate optional archive; external source disclosure is undecided.

Current Field Owner: field-miner-playwright-unified-20261010; declared commit 8ce386f2f2987c8a4d6ab327e4f9777abc7b061f. Owner tools lock Playwright 1.63.0 / Chromium 153; site105 and source137 bytes are unchanged. Independent final Owner setup plus 33 tool / 8 budget / 13 migration checks passed. Two worker 176-case runs were reviewed with 225 matching functional inputs; they are not claimed as root full-regression reruns. Existing SITE-RECORD Runtime identity is deliberately unchanged.

Current r4 tooling is a candidate pending independent review. Use ../../GETTING-STARTED.md and ../../UPDATE-ROLLBACK.md for the complete Caddy recipe. CloudBase supports only a unique new version-path trial with no verified shielding/switch/rollback. Old fixed-path SW/PWA migrations remain unverified. No diagnostic mode or full regression command is shipped.
