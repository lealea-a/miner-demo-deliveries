const BASE = self.registration.scope;
const CACHE_PREFIX = 'field-miner:' + BASE + '|';
const CACHE_NAME = CACHE_PREFIX + "field-miner-portable-candidate-20261010-d31c1071fba416f2cfdd31a2c64f839713b1e1f6e98ff6d0e573c27554181847";
const PRECACHE_URLS = ["RELEASE_MANIFEST.json","assets/field-dialog-light-dismiss-D525Ri39.js","assets/field-entry-exit-trial-HnYslKmx.css","assets/field-entry-exit-trial.html-BTyKFBX7.js","assets/field-entry-flight-s16-rgba-v01-1x.png","assets/field-entry-flight-s16-rgba-v01-2p5x.png","assets/field-entry-flight-s16-rgba-v01-2x.png","assets/field-entry-webgl-poster-s0-v01-1x.png","assets/field-entry-webgl-poster-s0-v01-2x.png","assets/field-first-use-narrative-layout-trial-v01-dtV5RVv9.css","assets/field-first-use-narrative-layout-trial-v01.html-B8bsiiDt.js","assets/field-first-use-source-han-cn-light-300-v01-hqZlnke9.woff2","assets/field-frame-fit-B7vsEWCt.js","assets/field-inner-content-CJdAHMSh.js","assets/field-inner-cover-aligned-rgba-v01.png","assets/field-inner-cover-preview-CdhXbzZy.css","assets/field-inner-cover-preview.html-T634SBaG.js","assets/field-inner-current-field-sheet-DpYb-tiW.js","assets/field-inner-d04-content-v02.svg","assets/field-inner-scope-switch-CI2db982.js","assets/field-inner-slider-kSMp7rct.js","assets/frame1-field-body.svg","assets/frame1-field-source.svg","assets/modulepreload-polyfill-B5Qt9EMX.js","assets/registry-DPnXnJxU.js","assets/source-han-sans-cn-extra-light-200-field-global-v11-BhHoqUnA.woff2","assets/source-han-sans-cn-extra-light-250-site-v2-0p_-55kD.woff2","assets/source-han-sans-cn-light-300-field-global-v11-BTMIWdoD.woff2","assets/source-han-sans-cn-light-300-site-v2-CGbBaqr5.woff2","assets/source-han-sans-cn-medium-500-site-v2-4XvtPrsE.woff2","assets/source-han-sans-cn-normal-350-field-global-v11-Djdw9qJi.woff2","assets/source-han-sans-cn-normal-350-site-v2-q2bwJcox.woff2","assets/vendor/carbon/information-16.svg","field-entry-exit-trial.html","field-first-use-narrative-layout-trial-v01.html","field-inner-cover-preview.html","icons/icon-192.png","icons/icon-512.png","index.html","licenses/COMPONENTS.json","licenses/INDEX.txt","licenses/carbon-Apache-2.0.txt","licenses/embla-8.6.0.txt","licenses/floating-core-1.8.0.txt","licenses/floating-dom-1.8.0.txt","licenses/floating-utils-0.2.12.txt","licenses/gesture-core-10.3.1.txt","licenses/gesture-vanilla-10.3.1.txt","licenses/source-han.txt","licenses/three-0.180.0.txt","manifest.webmanifest"].map(file => new URL(file, BASE).href);

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS.map((url) => new Request(url, { cache: 'reload' })))),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys
          .filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME)
          .map((key) => caches.delete(key)),
      )),
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || !url.href.startsWith(BASE)) {
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(event.request, {
      ignoreSearch: event.request.mode === 'navigate',
      cacheName: CACHE_NAME,
    });
    if (cached) return cached;

    try {
      const response = await fetch(event.request);
      if (response.ok) {
        try {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(event.request, response.clone());
        } catch (cacheError) {
          console.warn('FIELD_SW_CACHE_WRITE_FAILED', cacheError);
        }
      }
      return response;
    } catch (error) {
      if (event.request.mode === 'navigate') {
        const fallback = await caches.match(`${BASE}field-entry-exit-trial.html`, { cacheName: CACHE_NAME });
        if (fallback) return fallback;
      }
      throw error;
    }
  })());
});
