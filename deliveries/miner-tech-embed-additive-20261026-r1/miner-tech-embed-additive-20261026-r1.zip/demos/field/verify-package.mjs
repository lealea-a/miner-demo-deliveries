import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const base=path.dirname(fileURLToPath(import.meta.url));
const mutableDirs=new Set(['.git','node_modules','.owner-cache','.owner-browsers','output']);
const engineeringMutable=new Set(['engineering/field/node_modules','engineering/field/dist']);
function walk(d,root=false){return fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>{assert.ok(!e.isSymbolicLink(),'SYMLINK_REJECTED '+e.name);const relative=path.relative(base,path.join(d,e.name)).replaceAll('\\','/');if((root&&mutableDirs.has(e.name))||engineeringMutable.has(relative)){assert.ok(e.isDirectory(),'MUTABLE_ROOT_MUST_BE_DIRECTORY '+e.name);return [];}if(root&&e.name==='owner.config.json'){assert.ok(e.isFile(),'CONFIG_MUST_BE_FILE');return [];}return e.isDirectory()?walk(path.join(d,e.name)).map(f=>e.name+'/'+f):[e.name];}).sort();}
const lines=fs.readFileSync(path.join(base,'FILES.sha256'),'utf8').trim();assert.ok(lines,'EMPTY_MANIFEST');
const rows=lines.split(/\r?\n/).map(l=>{const m=l.match(/^([a-f0-9]{64})  (.+)$/);assert.ok(m,'INVALID_MANIFEST_LINE');assert.ok(!path.isAbsolute(m[2])&&!m[2].includes('\\')&&!m[2].split('/').some(p=>['..','.',''].includes(p)),'UNSAFE_MANIFEST_PATH');assert.ok(!mutableDirs.has(m[2].split('/')[0])&&m[2]!=='owner.config.json','MUTABLE_PATH_IN_MANIFEST');return {sha:m[1],file:m[2]};});
assert.equal(new Set(rows.map(r=>r.file)).size,rows.length);assert.deepEqual(walk(base,true),rows.map(r=>r.file).concat('FILES.sha256').sort(),'PACKAGE_FILE_SET_MISMATCH');
for(const r of rows)assert.ok(![...engineeringMutable].some(p=>r.file===p||r.file.startsWith(p+'/')),'MUTABLE_PATH_IN_MANIFEST');
for(const r of rows)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(base,r.file))).digest('hex'),r.sha,r.file);console.log('PASS complete immutable file set and SHA: '+(rows.length+1));
