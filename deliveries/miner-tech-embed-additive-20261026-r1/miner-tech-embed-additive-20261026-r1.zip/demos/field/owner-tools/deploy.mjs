import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {root, prerequisites, runNode, dependency, freshRun, sha} from './common.mjs';
import {deployment, readConfig} from './deploy-config.mjs';
import {verifyPublic} from './public-acceptance.mjs';

export const capabilities = {operation:'NEW_VERSION_PATH_TRIAL_ONLY', completeReleaseSwitch:false,
  accessShielding:false, automaticRollback:false, missing:['platform routing/response headers','unrouted upload isolation','verified alias switch and rollback'],
  supportedCompleteRecipe:'../../GETTING-STARTED.md (Caddy)'};
export function assertEmptyTarget(stdout) {
  let data;
  try {data = JSON.parse(stdout);} catch {throw Error('TARGET_LIST_JSON_UNPARSEABLE');}
  assert.ok(Array.isArray(data.data) && data.data.length === 0, 'TARGET_NOT_EMPTY_OR_UNKNOWN');
}
export function reserveTrial(config, directory) {
  assert.match(config.releaseId || '', /^release-[A-Za-z0-9_-]{8,100}$/, 'UNIQUE_RELEASE_ID_REQUIRED');
  assert.equal(config.targetRoot.split('/').at(-1), config.releaseId, 'TARGET_MUST_END_IN_RELEASE_ID');
  fs.mkdirSync(directory, {recursive:true});
  const key = sha(Buffer.from(config.environmentId + '/' + config.targetRoot));
  // Exclusive creation; even a failed or interrupted attempt remains reserved.
  const file = path.join(directory, key + '.json');
  fs.writeFileSync(file, JSON.stringify({environmentId:config.environmentId,targetRoot:config.targetRoot,
    releaseId:config.releaseId,createdAt:new Date().toISOString(),state:'ATTEMPTED_DO_NOT_REUSE'}), {flag:'wx'});
  return file;
}

export async function uploadAndAccept(upload, accept, out) {
  const result = {uploadSucceeded:false, publicAcceptanceFailed:false, status:'FAIL',
    scope:'NEW_VERSION_PATH_TRIAL_ONLY',stableAliasChanged:false,automaticRollback:false,
    failureAction:'Preserve attempted target and logs; select a new unique target. Partial content may be publicly accessible.'};
  try {
    await upload();
    result.uploadSucceeded = true;
    try {await accept();}
    catch (error) {result.publicAcceptanceFailed = true; throw error;}
    result.status = 'PASS';
    return result;
  } catch (error) {
    result.error = String(error.stack);
    throw error;
  } finally {
    fs.writeFileSync(path.join(out,'deployment-result.json'), JSON.stringify(result, null, 2));
  }
}
export async function main(args) {
  prerequisites();
  const mode = args[2];
  assert.ok(['plan','deploy'].includes(mode), 'CLOUDBASE_SWITCH_ROLLBACK_UNSUPPORTED');
  const config = readConfig(args, root);
  assert.match(config.environmentId || '', /^[a-zA-Z0-9][a-zA-Z0-9_-]{2,100}$/, 'OWNER_ENV_REQUIRED');
  const {site,record,domain} = deployment(config);
  dependency('@cloudbase/cli');
  const cli = path.join(root, 'node_modules/@cloudbase/cli/bin/cloudbase');
  const cliArgs = ['hosting','deploy',site,config.targetRoot,'-e',config.environmentId,'--safe','--verify','--entry',
    record.completeFiles.filter(row => row.file.endsWith('.html')).map(row => row.file).join(','),'--json'];
  console.log(JSON.stringify({mode:'LOCAL_PLAN_NO_REMOTE_ACTION',site,files:record.completeFiles.length,
    environmentId:config.environmentId,targetRoot:config.targetRoot,publicDomain:domain.origin,cli,arguments:cliArgs,
    siteManifestSha256:sha(fs.readFileSync(path.join(root,'SITE-RECORD.json'))),
    entries:Object.fromEntries(Object.entries(record.layouts).map(([layout,value])=>[layout,new URL(config.targetRoot+'/'+value.directory+'/'+value.entry,domain).href])),
    serviceWorker:new URL(config.targetRoot+'/'+record.layouts.portrait.directory+'/'+record.layouts.portrait.sw,domain).href,
    capabilities, remoteVerified:false}, null, 2));
  if (mode === 'deploy') {
    assert.ok(args.includes('--confirm-upload'), 'Explicit deploy requires --confirm-upload after reviewing deploy:plan');
    const out = freshRun('deploy');
    reserveTrial(config, path.join(root,'output','reserved-targets'));
    await uploadAndAccept(
      async () => {
        const listed = await runNode([cli,'hosting','list',config.targetRoot,'-e',config.environmentId,'--json'],
          {log:path.join(out,'target-before.json')});
        assertEmptyTarget(listed.stdout);
        deployment(config);
        await runNode([cli,...cliArgs], {log:path.join(out,'upload-process.json')});
      },
      () => verifyPublic(config, path.join(out,'public-acceptance')), out);
  }
}
import {fileURLToPath} from 'node:url';
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main(process.argv);
