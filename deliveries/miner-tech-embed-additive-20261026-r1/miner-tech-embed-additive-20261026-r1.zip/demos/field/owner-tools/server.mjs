import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {randomUUID} from 'node:crypto';
import {root, site, verifyRuntime} from './common.mjs';
import {targetRoot as validateTargetRoot} from './deploy-config.mjs';

export const MIME = {'.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.svg':'image/svg+xml',
  '.png':'image/png', '.woff2':'font/woff2', '.json':'application/json', '.webmanifest':'application/manifest+json',
  '.csv':'text/csv', '.txt':'text/plain', '.md':'text/markdown', '.sha256':'text/plain'};
export async function serve({port = 0, diagnostic = false, targetRoot = null} = {}) {
  if (diagnostic) throw Error('DIAGNOSTIC_UNSUPPORTED_IN_SLIM_PACKAGE');
  const mount = targetRoot === null ? '' : '/' + validateTargetRoot(targetRoot);
  const instanceId = randomUUID();
  const runtimeIdentity = verifyRuntime();
  let identity;
  const server = http.createServer((req, res) => {
    let p;
    try {p = decodeURIComponent(new URL(req.url, 'http://local').pathname);}
    catch {res.writeHead(400).end(); return;}
    res.setHeader('Cache-Control', 'no-store');
    if (p === '/__field_owner_health') {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify(identity));
      return;
    }
    if (p === '/') {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.end(`<title>Field Miner local</title><h1>Field Miner portable candidate · Local PENDING_REVIEW</h1><ul><li><a href="${mount}/field-miner-mobile-v01/field-entry-exit-trial.html">Portrait</a></li><li><a href="${mount}/field-miner-landscape-simple-guide-v01/">Landscape</a></li></ul>`);
      return;
    }
    for (const leaf of ['field-miner-mobile-v01','field-miner-landscape-simple-guide-v01']) {
      if (p === mount + '/' + leaf) { res.writeHead(308,{Location:p + '/'}).end(); return; }
    }
    const portrait = p.startsWith(mount + '/field-miner-mobile-v01/');
    const leaf = portrait ? 'field-miner-mobile-v01' : 'field-miner-landscape-simple-guide-v01';
    const prefix = mount + '/' + leaf + '/';
    const base = path.join(site,leaf);
    const file = path.resolve(base, p.slice(prefix.length) || 'index.html');
    if (!p.startsWith(prefix) || !file.startsWith(base + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      res.writeHead(404).end(); return;
    }
    res.setHeader('Content-Type', MIME[path.extname(file)] || 'application/octet-stream');
    res.end(fs.readFileSync(file));
  });
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', resolve);
  });
  const actualPort = server.address().port;
  identity = {type: 'field-owner-ready', schemaVersion: 1, instanceId, pid: process.pid,
    origin: 'http://127.0.0.1:' + actualPort, port: actualPort, diagnostic, runtime: runtimeIdentity};
  return {server, identity, origin: identity.origin, close: () => new Promise(resolve => {
    server.close(resolve);
    server.closeAllConnections();
  })};
}
