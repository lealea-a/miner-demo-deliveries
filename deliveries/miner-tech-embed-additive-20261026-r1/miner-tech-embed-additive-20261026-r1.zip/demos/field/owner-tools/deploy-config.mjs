import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {site, siteRecord, verifySite} from './common.mjs';

export function targetRoot(value) {
  assert.equal(typeof value, 'string', 'TARGET_PATH_INVALID');
  assert.ok(value.length <= 240 && /^[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*$/.test(value), 'TARGET_PATH_INVALID');
  return value;
}

export function deployment(config, {fixture = false} = {}) {
  targetRoot(config.targetRoot);
  const domain = new URL(config.publicDomain);
  const loopback = ['127.0.0.1','localhost','[::1]'].includes(domain.hostname);
  assert.ok(domain.protocol === 'https:' || (fixture && loopback && domain.protocol === 'http:'), 'HTTPS_REQUIRED');
  assert.equal(domain.pathname, '/');
  assert.ok(!domain.username && !domain.password && !domain.search && !domain.hash, 'DOMAIN_ORIGIN_ONLY');
  const record = siteRecord();
  verifySite(site, record.completeFiles);
  return {domain, site, record, prefix:'/' + config.targetRoot + '/'};
}
export function readConfig(args, root) {
  const index = args.indexOf('--config');
  const file = index < 0 ? path.join(root, 'owner.config.json') : path.resolve(args[index + 1]);
  if (!fs.existsSync(file)) throw Error('OWNER_CONFIG_REQUIRED: supply your own owner.config.json');
  return JSON.parse(fs.readFileSync(file));
}
