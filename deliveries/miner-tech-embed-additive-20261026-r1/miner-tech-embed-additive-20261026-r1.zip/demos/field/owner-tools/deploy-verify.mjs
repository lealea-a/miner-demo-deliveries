import fs from 'node:fs';
import path from 'node:path';
import {root, prerequisites, freshRun} from './common.mjs';
import {readConfig} from './deploy-config.mjs';
import {verifyPublic} from './public-acceptance.mjs';

const out = freshRun('deploy-verify');
try {
  prerequisites();
  const result = await verifyPublic(readConfig(process.argv, root), out);
  console.log(JSON.stringify({status:result.status, files:result.files.length, browsers:result.browsers.length, out}));
} catch (error) {
  fs.writeFileSync(path.join(out,'failure.json'), JSON.stringify({status:'FAIL', error:String(error.stack)}, null, 2));
  throw error;
}
