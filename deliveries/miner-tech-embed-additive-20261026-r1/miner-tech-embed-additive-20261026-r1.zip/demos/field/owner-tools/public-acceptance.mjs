import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {root, sha, browserInfo, siteRecord} from './common.mjs';
import {deployment} from './deploy-config.mjs';

const MIME = {
  '.html':['text/html'], '.js':['text/javascript','application/javascript'], '.css':['text/css'],
  '.svg':['image/svg+xml'], '.png':['image/png'], '.woff2':['font/woff2','application/font-woff2'],
  '.json':['application/json'], '.webmanifest':['application/manifest+json','application/json'],
  '.csv':['text/csv','text/plain','application/octet-stream'], '.txt':['text/plain','application/octet-stream'],
  '.md':['text/plain','text/markdown','application/octet-stream'], '.sha256':['text/plain','application/octet-stream']
};
export function checkCache(headers) {
  const policies = ['cache-control','cdn-cache-control','surrogate-control'].filter(k => headers[k]);
  assert.ok(headers['cache-control'], 'CACHE_CONTROL_MISSING');
  for (const name of policies) {
    const fields = headers[name].toLowerCase().split(/,(?=(?:[^"]*"[^"]*")*[^"]*$)/).map(x => x.trim());
    assert.ok(!fields.some(x => /^immutable(?:=|$)/.test(x)), 'CACHE_IMMUTABLE');
    for (const key of ['max-age','s-maxage','stale-while-revalidate','stale-if-error']) {
      const matches = fields.filter(x => x.split('=')[0].trim() === key);
      assert.ok(matches.length <= 1, 'CACHE_DUPLICATE_TTL');
      for (const f of matches) assert.match(f, new RegExp('^' + key + '=\\s*"?0"?$'), 'CACHE_POSITIVE_OR_INVALID_TTL');
    }
    const safe = fields.includes('no-store') || fields.includes('no-cache') ||
      (fields.some(x => /^max-age=\s*"?0"?$/.test(x)) && fields.includes('must-revalidate'));
    assert.ok(safe, 'CACHE_REVALIDATION_REQUIRED ' + name);
  }
  if (headers.expires && headers.date) {
    const expires = Date.parse(headers.expires), date = Date.parse(headers.date);
    assert.ok(!Number.isFinite(expires) || !Number.isFinite(date) || expires <= date, 'CACHE_FUTURE_EXPIRES');
  }
}
export async function navigationEvidence(response,page,requested,out,label,row = {}) {
  Object.assign(row,{requestedUrl:requested,pass:false,hops:[]});
  try {
    assert.ok(response,'NAVIGATION_RESPONSE_MISSING');
    for(let request=response.request();request;request=request.redirectedFrom()) {
      const r=await request.response();
      row.hops.unshift({url:request.url(),status:r?.status(),location:r?.headers().location ?? null});
      assert.ok(row.hops.length<=6,'NAVIGATION_REDIRECT_LIMIT');
    }
    row.actualUrl=response.url();row.pageUrl=page.url();row.status=response.status();
    row.headers=Object.fromEntries(Object.entries(await response.allHeaders()).filter(([k])=>k!=='set-cookie'));
    row.fromServiceWorker=response.fromServiceWorker();
    const entry=label.startsWith('portrait')?'field-miner-mobile-v01/field-entry-exit-trial.html':'field-miner-landscape-simple-guide-v01/index.html';
    row.expectedSha256=siteRecord().completeFiles.find(r=>r.file===entry).sha256;
    const bytes=await response.body();row.actualSha256=sha(bytes);row.bytes=bytes.length;
    row.body=label+'-entry-body.html';fs.writeFileSync(path.join(out,row.body),bytes);
    assert.equal(row.status,200,'NAVIGATION_HTTP_STATUS');
    assert.equal(row.hops.length,1,'VERSION_ENTRY_REDIRECT_FORBIDDEN');
    assert.equal(row.actualUrl,requested,'NAVIGATION_FINAL_URL_MISMATCH');
    assert.equal(row.pageUrl,requested,'BROWSER_TARGET_MISMATCH');
    assert.equal((row.headers['content-type']||'').split(';')[0].trim().toLowerCase(),'text/html','NAVIGATION_MIME_MISMATCH');
    assert.equal(row.actualSha256,row.expectedSha256,'NAVIGATION_SHA_MISMATCH');
    checkCache(row.headers);row.pass=true;return row;
  } catch(error) {row.error=String(error.stack);throw error;}
  finally {fs.writeFileSync(path.join(out,label+'-entry-response.json'),JSON.stringify(row,null,2));}
}
export async function routeEvidence(base,signal) {
  const rows=[];
  for(const directory of ['field-miner-mobile-v01','field-miner-landscape-simple-guide-v01']) {
    const slash=new URL(directory+'/',base), bare=slash.href.slice(0,-1);
    const r=await fetch(bare,{redirect:'manual',signal});
    const row={kind:'bare',url:bare,status:r.status,location:r.headers.get('location'),pass:false};rows.push(row);
    await r.body?.cancel();
    row.pass=[301,302,307,308].includes(r.status)&&new URL(row.location||'__missing',bare).href===slash.href;
    const directoryResponse=await fetch(slash,{redirect:'manual',signal}),directoryBytes=Buffer.from(await directoryResponse.arrayBuffer());
    const directoryRow={kind:'directory-body',url:slash.href,status:directoryResponse.status,
      sha256:sha(directoryBytes),headers:Object.fromEntries(directoryResponse.headers),pass:false};rows.push(directoryRow);
    try {
      assert.equal(directoryRow.status,200,'DIRECTORY_STATUS');
      assert.equal((directoryRow.headers['content-type']||'').split(';')[0].trim(),'text/html','DIRECTORY_MIME');
      assert.equal(directoryRow.sha256,siteRecord().completeFiles.find(f=>f.file===directory+'/index.html').sha256,'DIRECTORY_SHA');
      checkCache(directoryRow.headers);directoryRow.pass=true;
    }catch(error){directoryRow.error=String(error.stack);}
    for(const ext of ['js','css','html']) {
      const url=new URL('__missing_'+crypto.randomUUID()+'.'+ext,slash);
      const response=await fetch(url,{redirect:'manual',signal}),bytes=Buffer.from(await response.arrayBuffer());
      rows.push({kind:'missing',url:url.href,status:response.status,sha256:sha(bytes),pass:response.status===404 &&
        !siteRecord().completeFiles.some(f=>f.file.endsWith('.html')&&f.sha256===sha(bytes))});
    }
  }
  return rows;
}
// Frozen landscape guide initially loads its literal src, then sets layout=landscape.
// A cancellation is accepted only with this complete same-frame replacement chain.
export function classifyReplacedNavigation(row,base) {
  if(row.layout!=='landscape')return;
  const initial=new URL('field-miner-landscape-simple-guide-v01/field-inner-cover-preview.html',base).href;
  const replacement=initial+'?layout=landscape';
  const guide=new URL('field-miner-landscape-simple-guide-v01/field-first-use-narrative-layout-trial-v01.html?sequence=1&entry=1&handoff=1&layout=landscape',base).href;
  for(const failed of row.requestFailures){
    if(failed.error!=='net::ERR_ABORTED'||!failed.navigation||failed.resourceType!=='document'||failed.url!==initial||failed.parentUrl!==guide)continue;
    const same=row.timeline.filter(e=>e.frameId===failed.frameId);
    const before=same.find(e=>e.type==='request'&&e.requestId===failed.requestId&&e.sequence<failed.sequence);
    const next=same.find(e=>e.type==='request'&&e.navigation&&e.sequence>failed.sequence);
    if(!before||!next||next.url!==replacement||next.parentUrl!==guide)continue;
    const completed=same.find(e=>e.type==='finished'&&e.requestId===next.requestId&&e.sequence>next.sequence);
    const navigated=same.find(e=>e.type==='navigated'&&e.url===replacement&&e.sequence>next.sequence);
    const ready=same.find(e=>e.type==='ready'&&e.state==='inner'&&e.url===replacement&&e.sequence>(completed?.sequence??Infinity));
    const body=row.navigationBodies.find(e=>e.requestId===next.requestId&&e.pass);
    if(completed&&navigated&&ready&&body&&!same.some(e=>e.type==='failed'&&e.requestId===next.requestId)){
      failed.classification='proven-same-frame-landscape-src-replacement';
      failed.proof={initialRequest:failed.requestId,replacementRequest:next.requestId,frameId:failed.frameId,
        sequences:[before.sequence,failed.sequence,next.sequence,navigated.sequence,completed.sequence,ready.sequence],body:body.body,sha256:body.sha256};
    }
  }
  // The same evidenced replacement can cancel the initial document's cover image
  // after that document committed. Require a verified re-fetch in the replacement.
  const image=new URL('assets/field-inner-cover-aligned-rgba-v01.png',initial).href;
  for(const failed of row.requestFailures){
    if(failed.error!=='net::ERR_ABORTED'||failed.navigation||failed.resourceType!=='image'||failed.url!==image||failed.parentUrl!==guide)continue;
    const same=row.timeline.filter(e=>e.frameId===failed.frameId);
    const oldDoc=same.find(e=>e.type==='navigated'&&e.url===initial&&e.sequence<failed.sequence);
    const before=same.find(e=>e.type==='request'&&e.requestId===failed.requestId&&e.frameUrl===initial);
    const next=same.find(e=>e.type==='request'&&e.navigation&&e.sequence>(before?.sequence??Infinity));
    if(!oldDoc||!before||!next||next.url!==replacement||next.parentUrl!==guide||next.sequence>=failed.sequence)continue;
    const navigated=same.find(e=>e.type==='navigated'&&e.url===replacement&&e.sequence>next.sequence);
    const completed=same.find(e=>e.type==='finished'&&e.requestId===next.requestId);
    const newImage=same.find(e=>e.type==='request'&&e.url===image&&e.resourceType==='image'&&e.frameUrl===replacement&&e.sequence>(navigated?.sequence??Infinity));
    const imageDone=same.find(e=>e.type==='finished'&&e.requestId===newImage?.requestId);
    const ready=same.find(e=>e.type==='ready'&&e.state==='inner'&&e.url===replacement&&e.sequence>(imageDone?.sequence??Infinity));
    if(navigated&&completed&&newImage&&imageDone&&ready&&failed.sequence<=navigated.sequence&&
      row.navigationBodies.some(e=>e.requestId===next.requestId&&e.pass)&&row.navigationBodies.some(e=>e.requestId===newImage.requestId&&e.pass)){
      failed.classification='proven-replaced-document-cover-image';
      failed.proof={frameId:failed.frameId,initialDocument:initial,replacementRequest:next.requestId,replacementImage:newImage.requestId,
        sequences:[oldDoc.sequence,before.sequence,next.sequence,failed.sequence,navigated.sequence,imageDone.sequence,ready.sequence]};
    }
  }
}
async function responseEvidence(file, expectedSha256, base, out, overallSignal) {
  const requested = new URL(file, base).href;
  const row = {file, requestedUrl:requested, expectedSha256, hops:[], pass:false};
  try {
    let url = requested, response;
    for (let hop = 0; hop < 5; hop++) {
      response = await fetch(url, {redirect:'manual', signal:overallSignal ? AbortSignal.any([overallSignal, AbortSignal.timeout(20000)]) : AbortSignal.timeout(20000)});
      const headers = Object.fromEntries([...response.headers].filter(([key]) => key !== 'set-cookie'));
      row.hops.push({url, status:response.status, headers});
      if (response.status >= 300 && response.status < 400) {
        const location = response.headers.get('location');
        assert.ok(location, 'REDIRECT_WITHOUT_LOCATION');
        const next = new URL(location, url);
        assert.ok(next.origin === base.origin && next.pathname.startsWith(base.pathname) && !next.search && !next.hash, 'REDIRECT_OUTSIDE_TARGET');
        await response.body?.cancel();
        url = next.href;
        if (hop === 4) throw Error('REDIRECT_LIMIT');
        continue;
      }
      break;
    }
    row.actualUrl = response.url;
    row.status = response.status;
    row.headers = row.hops.at(-1).headers;
    const bytes = Buffer.from(await response.arrayBuffer());
    row.bytes = bytes.length;
    row.actualSha256 = sha(bytes);
    const bodyPath = path.join(out, 'responses', file);
    fs.mkdirSync(path.dirname(bodyPath), {recursive:true});
    fs.writeFileSync(bodyPath, bytes);
    row.body = 'responses/' + file;
    assert.equal(row.status, 200, 'HTTP_STATUS');
    assert.equal(row.actualUrl, requested, 'UNEXPECTED_FINAL_URL');
    const mime = (row.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    assert.ok((MIME[path.extname(file)] || ['application/octet-stream']).includes(mime), 'MIME_MISMATCH ' + mime);
    assert.equal(row.actualSha256, expectedSha256, 'SHA_MISMATCH');
    // Existing names are not guaranteed content-addressed; all files use conservative revalidation.
    checkCache(row.headers);
    row.pass = true;
  } catch (error) {
    row.error = String(error.stack);
    row.cause = error.cause ? String(error.cause) : null;
  }
  return row;
}
export async function waitForActivatedSW(page, {timeout = 25000, interval = 100} = {}) {
  const started = Date.now(), observations = [];
  while (Date.now() - started < timeout) {
    // Node awaits evaluate fully before testing truthiness; never pass an async predicate to waitForFunction.
    const snapshot = await page.evaluate(async () => (await navigator.serviceWorker.getRegistrations()).map(r => ({
      scope:r.scope, scriptURL:r.active?.scriptURL ?? null, state:r.active?.state ?? null,
      installing:r.installing?.state ?? null, waiting:r.waiting?.state ?? null
    })));
    observations.push({elapsedMs:Date.now()-started, snapshot});
    if (snapshot.some(r => r.state === 'activated')) return {snapshot, observations};
    await new Promise(resolve => setTimeout(resolve, Math.min(interval, Math.max(1, timeout-(Date.now()-started)))));
  }
  throw Object.assign(Error('SW_ACTIVATION_TIMEOUT'), {observations});
}
function cleanLog(value) {
  return String(value ?? '').replace(/https?:\/\/[^\s)"']+/g, value => {
    try {const url=new URL(value);return url.origin+url.pathname;}catch{return '[URL]';}
  }).slice(0,4000);
}
function acceptanceBudget({timeoutMs = 180000, signal, now = () => performance.now(), onBoundary} = {}) {
  assert.ok(Number.isInteger(timeoutMs) && timeoutMs > 0, 'POSITIVE_TOTAL_BUDGET_REQUIRED');
  const started = now(), deadline = started + timeoutMs;
  const timerSignal = AbortSignal.timeout(timeoutMs);
  const combined = signal ? AbortSignal.any([timerSignal, signal]) : timerSignal;
  const events = [];
  return {
    signal:combined, timeoutMs, events,
    elapsed:() => now() - started,
    expired:() => combined.aborted || now() >= deadline,
    check(stage) {
      onBoundary?.(stage);
      const remainingMs = deadline - now();
      events.push({stage, elapsedMs:now()-started, remainingMs, aborted:combined.aborted});
      combined.throwIfAborted();
      if (remainingMs <= 0) throw new DOMException('Total acceptance deadline exceeded at ' + stage, 'TimeoutError');
      return remainingMs;
    }
  };
}
async function browserAcceptance(base, out, budget, launchOverride) {
  const signal = budget.signal;
  const rows = [], ownership = {launched:false, closeRequested:false, closed:false};
  let browser, closing, listenerRegistered = false, primaryError;
  // The abort callback observes rejection immediately; finally awaits the same close operation.
  const closeOwnedBrowser = () => {
    if (!closing) {
      ownership.closeRequested = true;
      closing = Promise.resolve().then(() => browser.close());
      closing.catch(() => {});
    }
    return closing;
  };
  const abort = () => {closeOwnedBrowser();};
  try {
    budget.check('before-browser-info');
    const {chromium, executable} = browserInfo();
    ownership.executable = executable;
    ownership.launchRemainingMs = budget.check('before-launch');
    const launchTimeout = Math.floor(ownership.launchRemainingMs);
    if (launchTimeout < 1) throw new DOMException('No positive launch budget remains', 'TimeoutError');
    ownership.launchTimeoutMs = launchTimeout;
    const launch = launchOverride || (options => chromium.launch(options));
    // Await directly: a late result is still owned by this finally; no losing Promise.race result.
    browser = await launch({headless:true, executablePath:executable, timeout:launchTimeout});
    ownership.launched = true;
    budget.check('after-launch');
    budget.check('before-abort-listener');
    signal.addEventListener('abort', abort, {once:true});
    listenerRegistered = true;
    budget.check('after-abort-listener');
    for (const portrait of [true,false]) {
      const layout = portrait ? 'portrait' : 'landscape';
      budget.check('before-' + layout + '-context');
      const context = await browser.newContext({viewport:portrait ? {width:390,height:844} : {width:1280,height:720}});
      budget.check('after-' + layout + '-context');
      const page = await context.newPage();
      budget.check('after-' + layout + '-page');
      page.setDefaultTimeout(Math.min(25000,budget.check('page-timeout')));
      const entry = portrait ? 'field-miner-mobile-v01/field-entry-exit-trial.html' : 'field-miner-landscape-simple-guide-v01/';
      const row = {layout:portrait ? 'portrait' : 'landscape', requestedUrl:new URL(entry, base).href, errors:[], failedResponses:[], requestFailures:[], console:[], pass:false};
      page.on('pageerror', error => row.errors.push(cleanLog(error.message)));
      const frames=new Map(),requests=new Map();row.timeline=[];row.navigationBodies=[];
      const pendingBodies=[];
      const frameId=frame=>{if(!frames.has(frame))frames.set(frame,'f'+frames.size);return frames.get(frame);};
      const requestId=request=>{if(!requests.has(request))requests.set(request,'r'+requests.size);return requests.get(request);};
      const event=(type,data)=>{const e={sequence:row.timeline.length,timeMs:performance.now(),type,...data};row.timeline.push(e);return e;};
      const requestData=request=>({requestId:requestId(request),frameId:frameId(request.frame()),frameUrl:request.frame().url(),parentUrl:request.frame().parentFrame()?.url()??null,url:request.url(),navigation:request.isNavigationRequest(),resourceType:request.resourceType()});
      page.on('request',r=>event('request',requestData(r)));
      page.on('requestfinished',r=>{
        const data=requestData(r);event('finished',data);
        const expected=new URL('field-miner-landscape-simple-guide-v01/field-inner-cover-preview.html?layout=landscape',base).href;
        const expectedImage=new URL('assets/field-inner-cover-aligned-rgba-v01.png',expected).href;
        const isDocument=r.isNavigationRequest()&&r.url()===expected;
        const isImage=r.resourceType()==='image'&&r.url()===expectedImage&&data.frameUrl===expected;
        if(isDocument||isImage){
          const evidence={...data,pass:false};row.navigationBodies.push(evidence);
          const p=(async()=>{
            const response=await r.response(),bytes=await response.body();
            Object.assign(evidence,{status:response.status(),headers:await response.allHeaders(),sha256:sha(bytes),body:layout+'-'+data.requestId+'-replacement.html'});
            fs.writeFileSync(path.join(out,evidence.body),bytes);
            assert.equal(evidence.status,200);assert.equal((evidence.headers['content-type']||'').split(';')[0].trim(),isDocument?'text/html':'image/png');
            const expectedFile='field-miner-landscape-simple-guide-v01/'+(isDocument?'field-inner-cover-preview.html':'assets/field-inner-cover-aligned-rgba-v01.png');
            assert.equal(evidence.sha256,siteRecord().completeFiles.find(f=>f.file===expectedFile).sha256);
            checkCache(evidence.headers);evidence.pass=true;
          })().catch(error=>{evidence.error=String(error.stack);});
          pendingBodies.push(p);
        }
      });
      page.on('framenavigated',f=>event('navigated',{frameId:frameId(f),url:f.url()}));
      page.on('requestfailed', request => row.requestFailures.push(event('failed',{...requestData(request),error:cleanLog(request.failure()?.errorText),classification:'unclassified'})));
      page.on('console', message => {
        if (['error','warning'].includes(message.type())) row.console.push({type:message.type(), text:cleanLog(message.text())});
      });
      page.on('response', response => {
        event('response',{...requestData(response.request()),status:response.status()});
        if (response.status() >= 400) {
          row.failedResponses.push({url:response.url().split('?')[0], status:response.status(), classification:'unresolved'});
        }
      });
      try {
        // Fresh contexts have no inherited cookies, storage or service workers.
        const entryResponse = await page.goto(row.requestedUrl, {waitUntil:'domcontentloaded'});
        row.entry={};
        await navigationEvidence(entryResponse,page,row.requestedUrl,out,layout,row.entry);
        const text = await page.locator('body').innerText();
        row.platformPrompt = text.includes('页面访问提示');
        assert.ok(!row.platformPrompt,'PLATFORM_NOTICE_NOT_DIRECT_HOSTING');
        await page.waitForFunction(() => document.documentElement.dataset.fieldEntryHandoffStatus === 'ready');
        event('ready',{frameId:frameId(page.mainFrame()),url:page.url(),state:'entry'});
        row.finalUrl = page.url();
        assert.equal(row.finalUrl, row.requestedUrl, 'BROWSER_TARGET_MISMATCH');
        await page.screenshot({path:path.join(out, row.layout + '-cover.png')});
        await page.locator('[data-field-entry-exit-link]').click();
        await page.waitForFunction(() => window.__FIELD_ENTRY_HANDOFF__?.phase === 'INNER');
        const guide = page.frames().find(frame => frame.url().includes('field-first-use-narrative'));
        assert.ok(guide, 'GUIDE_FRAME_MISSING');
        await guide.waitForFunction(() => document.documentElement.dataset.sequenceStatus === 'running');
        await guide.getByRole('button', {name:/跳过/}).click();
        await guide.waitForFunction(() => document.documentElement.dataset.sequenceStatus !== 'running');
        const inner = page.frames().find(frame => frame.url().includes('field-inner-cover-preview'));
        assert.ok(inner, 'INNER_FRAME_MISSING');
        await inner.waitForFunction(() => document.documentElement.dataset.previewStatus === 'ready');
        event('ready',{frameId:frameId(inner),url:inner.url(),state:'inner'});
        row.inner = true;
        await page.screenshot({path:path.join(out, row.layout + '-inner.png')});
        if (portrait) {
          const observed = await waitForActivatedSW(page);
          row.serviceWorkerPolling = observed.observations;
          row.serviceWorkers = observed.snapshot.map(({scope,scriptURL,state}) => ({scope,scriptURL,state}));
          const scope = new URL('field-miner-mobile-v01/', base).href;
          assert.deepEqual(row.serviceWorkers, [{scope, scriptURL:scope + 'sw.js', state:'activated'}], 'SW_IDENTITY_MISMATCH');
          row.reload={};
          const reloaded=await page.reload({waitUntil:'domcontentloaded'});
          await navigationEvidence(reloaded,page,row.requestedUrl,out,layout+'-reload',row.reload);
          assert.ok(row.reload.fromServiceWorker,'SW_CONTROLLED_RELOAD_REQUIRED');
          await page.waitForFunction(()=>document.documentElement.dataset.fieldEntryHandoffStatus==='ready');
        } else {
          row.serviceWorkers = await page.evaluate(async () => (await navigator.serviceWorker.getRegistrations()).map(r => ({scope:r.scope, scriptURL:r.active?.scriptURL})));
          assert.deepEqual(row.serviceWorkers, [], 'UNEXPECTED_LANDSCAPE_SW');
        }
        assert.deepEqual(row.errors, [], 'BROWSER_ERRORS');
        budget.check('before-response-bodies');
        await Promise.all(pendingBodies);
        budget.check('after-response-bodies');
        assert.ok(row.navigationBodies.every(e=>e.pass),'REPLACEMENT_BODY_EVIDENCE_FAILED');
        classifyReplacedNavigation(row,base);
        assert.deepEqual(row.failedResponses, [], 'BROWSER_HTTP_ERRORS');
        assert.deepEqual(row.requestFailures.filter(r=>r.classification==='unclassified'), [], 'BROWSER_REQUEST_FAILURES');
        assert.deepEqual(row.console.filter(r=>r.type==='error'), [], 'BROWSER_CONSOLE_ERRORS');
        budget.check('before-' + layout + '-pass');
        row.pass = true;
      } catch (error) {
        row.error = String(error.stack);
        if (error.observations) row.serviceWorkerPolling = error.observations;
        row.failureState = await page.evaluate(() => ({
          ready:document.documentElement.dataset.fieldEntryHandoffStatus ?? null,
          phase:window.__FIELD_ENTRY_HANDOFF__?.phase ?? null,
          title:document.title
        })).catch(error=>({unavailable:String(error.message)}));
        row.visibleText = cleanLog(await page.locator('body').innerText({timeout:1500}).catch(()=>''));
        row.finalUrl = page.url();
        await page.screenshot({path:path.join(out, row.layout + '-failure.png')}).catch(() => {});
      } finally {
        await Promise.all(pendingBodies);
        rows.push(row);
        fs.writeFileSync(path.join(out,'browser.json'), JSON.stringify({version:browser.version(), executable:ownership.executable, rows}, null, 2));
        await context.close();
      }
      budget.check('after-' + layout);
    }
    budget.check('after-browser-layouts');
  } catch (error) {
    primaryError = error;
    throw error;
  } finally {
    if (listenerRegistered) signal.removeEventListener('abort', abort);
    try {
      if (browser) {
        await closeOwnedBrowser();
        ownership.closed = true;
        ownership.connectedAfterClose = browser.isConnected();
      }
    } catch (cleanupError) {
      ownership.cleanupError = String(cleanupError.stack);
      if (primaryError) throw new AggregateError([primaryError, cleanupError], 'Acceptance and browser cleanup failed');
      throw cleanupError;
    } finally {
      fs.writeFileSync(path.join(out,'browser-ownership.json'), JSON.stringify(ownership, null, 2));
    }
  }
  return rows;
}
// Production always constructs the same fixed 180000 ms budget, including HTTP and browser work.
export function verifyPublic(config, out, {fixture = false} = {}) {
  return verifyPublicCore(config, out, fixture, acceptanceBudget());
}
// Explicit loopback-only fault-injection entry. CLI/deploy never call it or accept budget overrides.
export function verifyPublicForTest(config, out, options = {}) {
  const domain = new URL(config.publicDomain);
  assert.ok(['127.0.0.1','localhost','[::1]'].includes(domain.hostname), 'TEST_LOOPBACK_REQUIRED');
  const {launch, ...budgetOptions} = options;
  return verifyPublicCore(config, out, true, acceptanceBudget(budgetOptions), launch);
}
async function verifyPublicCore(config, out, fixture, budget, launchOverride) {
  fs.mkdirSync(out, {recursive:true});
  const result = {status:'FAIL', fixture, at:new Date().toISOString(), files:[], browsers:[], totalTimeoutMs:budget.timeoutMs};
  const signal = budget.signal;
  try {
    budget.check('entry');
    const {domain, record, prefix} = deployment(config, {fixture});
    const base = new URL(prefix, domain);
    result.base = base.href;
    result.expectedFiles = record.completeFiles.length;
    result.siteManifestSha256 = sha(fs.readFileSync(path.join(root,'SITE-RECORD.json')));
    let transportStopped = false;
    for (const file of record.completeFiles) {
      if (transportStopped || budget.expired()) {
        result.files.push({file:file.file, pass:false, status:'NOT_RUN', reason:'Shared transport failure or overall deadline'});
      } else {
        budget.check('before-http-file');
        const row = await responseEvidence(file.file, file.sha256, base, out, signal);
        result.files.push(row);
        if (!row.hops.length && row.error) transportStopped = true;
      }
      fs.writeFileSync(path.join(out, 'http.json'), JSON.stringify(result.files, null, 2));
    }
    budget.check('before-routes');
    result.routes=transportStopped||budget.expired()?[]:await routeEvidence(base,signal);
    // Keep browser evidence even when HTTP validation failed; neither can override the other.
    result.browsers = transportStopped || budget.expired() ? [{status:'NOT_RUN', reason:'Shared transport failure or overall deadline', pass:false}] : await browserAcceptance(base, out, budget, launchOverride);
    assert.equal(result.files.length, record.completeFiles.length);
    assert.equal(new Set(result.files.map(row => row.file)).size, record.completeFiles.length);
    assert.ok(result.files.every(row => row.pass), 'PUBLIC_HTTP_ACCEPTANCE_FAILED');
    assert.equal(result.routes.length,10,'ROUTE_EVIDENCE_REQUIRED');
    assert.ok(result.routes.every(row=>row.pass),'PUBLIC_ROUTE_ACCEPTANCE_FAILED');
    assert.equal(result.browsers.length, 2);
    assert.ok(result.browsers.every(row => row.pass), 'PUBLIC_BROWSER_ACCEPTANCE_FAILED');
    budget.check('before-final-pass');
    result.status = 'PASS';
    return result;
  } catch (error) {
    result.error = String(error.stack);
    if (error instanceof AggregateError) result.causes = error.errors.map(e => String(e.stack));
    throw Object.assign(Error('PUBLIC_ACCEPTANCE_FAILED: ' + error.message), {cause:error});
  } finally {
    result.elapsedMs = budget.elapsed();
    result.budgetChecks = budget.events;
    fs.writeFileSync(path.join(out, 'summary.json'), JSON.stringify(result, null, 2));
  }
}
export {responseEvidence};
