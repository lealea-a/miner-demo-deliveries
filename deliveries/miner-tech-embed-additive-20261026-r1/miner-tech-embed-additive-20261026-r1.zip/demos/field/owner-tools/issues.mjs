import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {root,require,dependency} from './common.mjs';
export function validate(report){dependency('ajv');const Ajv=require('ajv'),ajv=new Ajv({allErrors:true,strict:true}),schema=JSON.parse(fs.readFileSync(path.join(root,'issue-report.schema.json'))),check=ajv.compile(schema);if(!check(report))throw Error('ISSUE_SCHEMA_INVALID '+JSON.stringify(check.errors));return true;}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){for(const f of process.argv.slice(2).length?process.argv.slice(2):['issue-report.template.json','issue-report.safari-example.json']){validate(JSON.parse(fs.readFileSync(path.resolve(root,f))));console.log('VALID '+f);}}

