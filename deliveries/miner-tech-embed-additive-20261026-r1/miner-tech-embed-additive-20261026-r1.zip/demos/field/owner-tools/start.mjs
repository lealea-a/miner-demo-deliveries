import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {root, prerequisites, freshRun} from './common.mjs';
import {readConfig, targetRoot} from './deploy-config.mjs';
import {serve} from './server.mjs';

try {
  assert.ok(!process.argv.includes('--diagnostic'), 'DIAGNOSTIC_UNSUPPORTED_IN_SLIM_PACKAGE');
  prerequisites();
  const portIndex = process.argv.indexOf('--port');
  const port = portIndex < 0 ? 8781 : Number(process.argv[portIndex + 1]);
  assert.ok(Number.isInteger(port) && port >= 0 && port <= 65535, 'INVALID_PORT');
  const config = process.argv.includes('--config') || fs.existsSync(path.join(root,'owner.config.json')) ? readConfig(process.argv,root) : {targetRoot:'owner-field'};
  const service = await serve({port, targetRoot:targetRoot(config.targetRoot)});
  // The only readiness announcement follows the successful listen event.
  console.log(JSON.stringify(service.identity));
  const stop = async () => {await service.close(); process.exit(0);};
  process.once('SIGINT', stop);
  process.once('SIGTERM', stop);
} catch (error) {
  const out = freshRun('start');
  fs.writeFileSync(path.join(out, 'failure.json'), JSON.stringify({status:'FAIL', stage:'start', error:String(error.stack)}, null, 2));
  throw error;
}
