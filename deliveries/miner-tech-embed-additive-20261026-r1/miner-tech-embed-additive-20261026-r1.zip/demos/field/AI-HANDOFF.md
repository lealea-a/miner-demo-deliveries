# Field Miner AI handoff

Read README.md, DEPLOYMENT.md and SITE-RECORD.json. Formal Runtime is site/ (105 exact files); do not reconstruct from a different working tree or replace it with old Field r2. This is a slim derived integration, not the original 5332-file Owner archive. The retained Owner commands are listed in package.json; full regression, diagnostic fixtures and maintenance source are not shipped here.

Input Owner SHA256 1499721119397a1728d1b064b1f6a73a969bc547897b4938741a36b709238fdb. Issue delivery.runtimeSha256 is the exact SITE-RECORD SHA256 12a683e47183f8d0c6601719035c3adc7641c16f5f344a02ef229f207f787349, not the integrated ZIP hash. Integrated transport identity is recorded in the supplied ZIP.sha256 and ../../VERSION-INDEX.json maps inputs. Validate issue JSON with the retained schema and npm.cmd run issue:validate after setup. Describe the actual first failure and evidence; never report credentials/cookies/query secrets.

Both layouts share the approved cover effect, remain independently deployable, and carry their own licenses. No Runtime, assets, gestures, Registry or visual behavior was changed during integration. Do not alter manifest.id to achieve URL relocation. Scope isolation does not promise independent installation identity or localStorage.

Safari and historical landscape readiness causes remain unknown. No new real-device, HTTPS/cloud upload, manual cloud rollback, Linux or final user visual acceptance. Original technical evidence 176 regression checks (including 6 smoke), 13 migration groups, 33 Owner-tool and 8 budget checks is reused, not claimed rerun by this integration.

Current Field Owner: field-miner-playwright-unified-20261010; declared commit 8ce386f2f2987c8a4d6ab327e4f9777abc7b061f. Owner tools lock Playwright 1.63.0 / Chromium 153; site105 and source137 bytes are unchanged. Independent final Owner setup plus 33 tool / 8 budget / 13 migration checks passed. Two worker 176-case runs were reviewed with 225 matching functional inputs; they are not claimed as root full-regression reruns. Existing SITE-RECORD Runtime identity is deliberately unchanged.

Current r4 tooling is a candidate pending independent review. Use ../../GETTING-STARTED.md and ../../UPDATE-ROLLBACK.md for the complete Caddy recipe. CloudBase supports only a unique new version-path trial with no verified shielding/switch/rollback. Old fixed-path SW/PWA migrations remain unverified. No diagnostic mode or full regression command is shipped.
