# 本次 Tech iframe 增量候选：先读 EMBED-UPDATE.md

本包新增第三个独立站点 `tech-embed`，请先按 [EMBED-UPDATE.md](EMBED-UPDATE.md) 的 prepare → verify → 追加 approved → config/validate → reload → 公网 HTTP 核验顺序操作。旧 Field/Tech alias 继续指向原 active（演练为 release-A），不要切换 active。新入口为 `/_releases/release-tech-embed-20261026-r1/tech-embed/embed.html`；父 origin 必须同时匹配 bridge 与此路径专用 CSP，具体允许列表及验证命令见该文档。本包尚未发布。

以下为保留的 r4 历史说明，其中 two sites 和原 Tech CSP 仅描述原有 Field/Tech，不包含本次新入口，不作为本次部署步骤。

# r4 candidate: immutable static releases

This package contains Field (105 files) and Tech (124 files), with unchanged site bytes. r4 changes Owner tooling and hosting instructions; it awaits independent review. TECH-FREEZE.json describes historical inputs, not r4 approval.

Use Caddy **2.10.2**, upstream commit `551f793700fe1550845c824470b623fd1aa03d36`. Obtain the official Windows amd64 ZIP from https://github.com/caddyserver/caddy/releases/tag/v2.10.2 and verify SHA256 `9fd1ef9be5d9b05852b66ccc25f96f23d8651bcab20779861a745bdffa273722`. The binary is not bundled. Caddy serves the sites without Node, npm, maintenance source or Owner dependencies. Preparation/verification commands below run on an Owner workstation with Windows 11 x64 and Node 24.21.0/npm 11.19.0. No Windows service installation is included.

1. Verify the received ZIP SHA against the separately supplied trusted digest, extract, then run `node verify-package.mjs` at its root. This checks bytes, not distributor authentication.
2. Pick a new release ID and a server directory outside this package. Never reuse an existing, failed or partial release directory. Set `$releaseRoot = 'C:/Miner/releases'` and `$releaseId = 'release-A'`. Run `node deploy/release.mjs prepare $releaseRoot $releaseId`. This copies only the two sites and verifies every file. Copy/upload failures leave an unrouted partial directory; preserve it and select a new ID.
3. Create a spec outside the package (or under root `output/`), using the structure below. `approved` is an explicit allowlist of complete verified releases, not a filesystem wildcard. Start with `active: null` so public aliases remain unavailable. Run `node deploy/release.mjs config C:/Miner/stage-A.json C:/Miner/stage-A.caddy`. The command rejects incomplete or changed release bytes and existing output files.
4. Run `caddy validate --config C:/Miner/stage-A.caddy --adapter caddyfile`. Require exit 0. Start with `caddy run --config C:/Miner/stage-A.caddy --adapter caddyfile` in your managed console/process. Supply your actual DNS name and network/HTTPS prerequisites; local HTTP evidence is not public TLS validation. See deploy/Caddyfile.example for the generated first-release structure.
5. On the Owner workstation run each Demo's `npm.cmd run setup` in its own directory. No sibling/global node_modules or shared browser is used. Configure Field publicDomain as `https://YOUR-DOMAIN`, targetRoot as `_releases/release-A/field`; Tech domain as that origin and deploymentPrefix as `_releases/release-A/tech`. Other required fields follow the examples. Run each `npm.cmd run deploy:verify`. These are read-only checks of all files plus actual Chromium response/interaction evidence; require both to succeed before exposing aliases. The Field portrait must also pass SW-controlled reload. Do not use CloudBase deploy for this Caddy filesystem workflow.
6. Generate a second spec with `active: "release-A"`; validate and reload that config. Run `node deploy/release.mjs aliases https://YOUR-DOMAIN release-A` and repeat both version URL acceptance commands. Apply the persistence and failure-recovery procedure in UPDATE-ROLLBACK.md before declaring the release current.

```json
{
  "address": "YOUR-DOMAIN.example",
  "admin": "127.0.0.1:2019",
  "releaseRoot": "C:/Miner/releases",
  "approved": ["release-A"],
  "active": null
}
```

For local diagnostics only, set address to `http://127.0.0.1:PORT`, admin to a separate unused loopback port, and `local: true`. Production defaults use HTTPS. Keep the admin API loopback-only.

Stable entries redirect with 302 and no-store to version URLs:

- `/demos/field/`: portrait `/_releases/release-A/field/field-miner-mobile-v01/field-entry-exit-trial.html`
- `/demos/field/field-miner-landscape-simple-guide-v01/`: landscape directory in that release
- `/demos/tech/`: `/_releases/release-A/tech/`

Caddy provides MIME, real 308 directory redirects and 404, no directory listing or SPA fallback, and no-store. Only Tech receives its original CSP policy. Leave approved release directories read-only and retain previous releases; do not alter their contents, symlinks, SW or manifest. Each layout remains self-contained with its licenses.

CloudBase is an optional **new version-path trial uploader**, not this complete release mechanism. Its CLI cannot provide verified upload access shielding, application alias switching or automatic rollback. deploy:plan lists these gaps; switch/rollback modes are rejected. --safe/--verify do not repair a SW cache already installed during a partial upload. A failed attempt is never automatically retried onto the same directory. No cloud login/upload, DNS/TLS/CDN, third-party machine, physical device/Safari or Windows service installation was validated in r4.

Existing fixed-path SW clients and installed PWA identity migration remain unverified. Preserve their old URLs. Do not clear caches, unregister workers, change manifest.id, or claim independent PWA installations. Optional maintenance sources remain separate and are unnecessary for deployment.
