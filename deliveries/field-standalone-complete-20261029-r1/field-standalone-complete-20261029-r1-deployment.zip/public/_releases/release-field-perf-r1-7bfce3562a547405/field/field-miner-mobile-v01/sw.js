const BASE = self.registration.scope;
const CACHE_PREFIX = 'field-miner:' + BASE + '|';
const CACHE_NAME = CACHE_PREFIX + "field-standalone-performance-r1-28d23d6a5014ceaa3c0478415a11a0a876912b9f47052fb26cd263b7f9f2d46e";
const PRECACHE_URLS = ["assets/entry-0i-8gHN-.js","assets/field-dialog-light-dismiss-D525Ri39.js","assets/field-entry-exit-trial-B1lhfT4V.css","assets/field-entry-exit-trial.html-BTUdFyW4.js","assets/field-entry-flight-s16-rgba-perf-r1-1x.png","assets/field-entry-webgl-poster-s0-perf-r1-1x.png","assets/field-first-use-narrative-layout-trial-v01-ByAtwiiQ.css","assets/field-first-use-narrative-layout-trial-v01.html-B3aiOB0w.js","assets/field-frame-fit-B7vsEWCt.js","assets/field-inner-content-swyB8__K.js","assets/field-inner-cover-aligned-rgba-perf-r1.png","assets/field-inner-cover-preview-CbYhMNEV.css","assets/field-inner-cover-preview.html-Benv-oVQ.js","assets/field-inner-current-field-sheet-DpYb-tiW.js","assets/field-inner-d04-content-v02.svg","assets/field-inner-scope-switch-DukC-4Wj.js","assets/field-inner-slider-NAwV_Rnx.js","assets/font-readiness-Dx8BnSGG.js","assets/frame1-field-body.svg","assets/main-CI9aNpTt.js","assets/modulepreload-polyfill-B5Qt9EMX.js","assets/preload-helper-PPVm8Dsz.js","assets/registry-DPnXnJxU.js","assets/source-han-sans-cn-extra-light-250-perf-r1-BCwC_4ZQ.woff2","assets/source-han-sans-cn-light-300-perf-r1-Dxs0NXT_.woff2","assets/source-han-sans-cn-medium-500-perf-r1-C9BZzt14.woff2","assets/source-han-sans-cn-normal-350-perf-r1-DZq51yYC.woff2","assets/vendor/carbon/information-16.svg","field-entry-exit-trial.html","field-first-use-narrative-layout-trial-v01.html","field-inner-cover-preview.html","icons/icon-192.png","icons/icon-512.png","index.html","manifest.webmanifest"].map(file => new URL(file, BASE).href);

const COMPLETE_URL = new URL('__field_offline_complete__', BASE).href;
self.addEventListener('install', event => {
  event.waitUntil((async()=>{
    try {
      const cache=await caches.open(CACHE_NAME);
      for(const url of PRECACHE_URLS){
        const response=await fetch(new Request(url,{cache:'default'}));
        if(!response.ok)throw Error('FIELD_SW_INSTALL_HTTP:'+response.status+':'+url);
        await cache.put(url,response);
      }
      await cache.put(COMPLETE_URL,new Response(JSON.stringify({cache:CACHE_NAME,files:PRECACHE_URLS.length,complete:true}),{headers:{'Content-Type':'application/json'}}));
    }catch(error){
      await caches.delete(CACHE_NAME);
      console.error('FIELD_SW_INSTALL_FAILED',error);
      throw error;
    }
  })());
});
// Preserve waiting and old-version clients; never skipWaiting/claim/delete old caches.
self.addEventListener('message',event=>{
  if(event.data?.type!=='FIELD_OFFLINE_STATUS')return;
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE_NAME),complete=await cache.match(COMPLETE_URL);
    event.ports[0]?.postMessage({type:'FIELD_OFFLINE_STATUS',cache:CACHE_NAME,complete:!!complete,files:PRECACHE_URLS.length});
  })());
});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin||!url.href.startsWith(BASE))return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE_NAME);
    const cached=await cache.match(event.request,{ignoreSearch:event.request.mode==='navigate'});
    if(cached)return cached;
    try{return await fetch(event.request);}catch(error){
      if(event.request.mode==='navigate'){
        const fallback=await cache.match(new URL('field-entry-exit-trial.html',BASE).href);
        if(fallback)return fallback;
      }
      throw error;
    }
  })());
});
