const e=Object.freeze({layoutId:"landscape-1920x1080",logicalWidth:1920,logicalHeight:1080}),N=Object.freeze({x:220.1193256,y:173.5881257});export{e as F,N as a};
