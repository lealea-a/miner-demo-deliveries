# Field 最新完整独立部署交付

整理日期：2026-10-29。交付编号：`field-standalone-complete-20261029-r1`。

这是一份已接受版本的组合交付，不是新构建或新的产品版本。横版采用 `71fc`，竖版采用 `7bfc`。两个目录保留各自原版本 ID、资源文件、缓存策略和许可证，不把组合包伪装成同一个源码摘要。

## 使用哪份文件

- `field-standalone-complete-20261029-r1-deployment.zip`：完整部署包。只公开其中 `public/` 的内容，其他文件供部署人员阅读。
- `field-standalone-complete-20261029-r1-maintenance.zip`：匹配的两份维护源码、原始构建身份和接受记录。不要上传到公开站点。
- `SHA256SUMS`：上述交付 ZIP 及 Web 接入计划的 SHA-256。
- `VERIFICATION.json`：冻结输入、复制字节、包内清单和 ZIP 解包读取的核验结果。
- `WEB-H5-INTEGRATION-PLAN.md`：下一批 Web 接入 Field、Tech 的具体计划；本轮未实施该计划。

部署包内部：

```text
public/_releases/
  release-field-perf-r1-71fc214d0b3b7f2e/field/
    field-miner-landscape-simple-guide-v01/    # 49 文件，横版
  release-field-perf-r1-7bfce3562a547405/field/
    field-miner-mobile-v01/                    # 50 文件，独立竖版
VERSION-INDEX.json
SHA256SUMS
DEPLOYMENT.md
deployment/nginx-reference.conf
```

这里的“独立竖版”不等于“手机 H5 优化内嵌版”。本交付没有包含或修改手机 H5 优化内嵌包，也不替换其引用。

## 已有线上入口

- 横版：https://demo.ektopod.cn/_releases/release-field-perf-r1-71fc214d0b3b7f2e/field/field-miner-landscape-simple-guide-v01/
- 竖版：https://demo.ektopod.cn/_releases/release-field-perf-r1-7bfce3562a547405/field/field-miner-mobile-v01/

两者已在此前发布并获用户接受。本轮仅整理本地交付，未上传、改默认地址、reload 服务、清缓存、推 Git 或重新构建产品。

Tech 继续使用其现有独立部署和原交付，不进入本次 Field ZIP。Web 内嵌计划另见上面的计划文件。

## 接受与源身份

横版：标签 `field-standalone-accepted-20261029-r1`，提交 `3bbc41958a766a9736278d0ce74531e06bbb131f`。

竖版：标签 `field-portrait-ruler-accepted-20261029-r1`，提交 `7a4388284d82803b12adebb4d948edee428e2b7c`。

部署包 `VERSION-INDEX.json` 逐项绑定这两个输入。原产品清单内较早的 `LOCAL_CANDIDATE_NOT_PUBLISHED` 等历史状态保留原字节；当前接受状态和实际线上入口以外层索引及冻结接受记录为准。
