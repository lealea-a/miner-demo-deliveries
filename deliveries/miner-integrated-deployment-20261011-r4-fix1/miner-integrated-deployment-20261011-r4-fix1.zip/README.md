# r4 remediation candidate — independent review pending

# Miner integrated deployment delivery

Field Playwright-unified Owner is included. Tech R10 rev2 replaces the previous Tech r3. Its approved original ZIP is frozen by TECH-FREEZE.json. Both Demo inputs have local technical acceptance; this new integrated ZIP awaits separate review and is not online.

## Deploy

Follow [GETTING-STARTED](GETTING-STARTED.md) and [UPDATE-ROLLBACK](UPDATE-ROLLBACK.md). Prepare complete immutable version directories, verify, then switch stable aliases. Never upload over the existing fixed paths. Do not upload this whole ZIP or its handoff/tools. No server-side Node, npm, PowerShell or source build is required. Each layout remains self-contained; do not deduplicate its assets.

- Field portrait: /demos/field/field-miner-mobile-v01/field-entry-exit-trial.html
- Field landscape: /demos/field/field-miner-landscape-simple-guide-v01/
- Tech R10 rev2: /demos/tech/

Use real directory redirects and 404s, correct MIME, and conservative no-store/strict revalidation. Apply Tech site/CSP.json as instructed by its handoff. Keep complete prior approved artifacts and follow each Demo's session/rollback instructions. No HTML SPA fallback.

## Read the Demo handoffs

- [Field README](demos/field/README.md), [AI handoff](demos/field/AI-HANDOFF.md), [issue JSON](demos/field/issue-report.template.json), [schema](demos/field/issue-report.schema.json).
- [Tech README](demos/tech/README.md), [AI handoff](demos/tech/AI-HANDOFF.txt), [issue template](demos/tech/ISSUE-TEMPLATE.json), [open issues](demos/tech/REVIEW-STATUS.json).

VERSION-INDEX.json binds exact input hashes. Both Demos’ full source ZIPs are separate and optional, not inside this deploy ZIP; external disclosure is undecided. Static deployment never depends on it. Field local Owner tools retain their stated Windows/Node requirements and optional network setup; Tech byte verification needs Node24.21.0; optional Owner setup installs its own locked dependencies/browser. No PowerShell7/pwsh requirement was introduced.

Verify downloaded ZIP against its supplied .sha256 first. After extraction, node verify-package.mjs checks the integrated file set; Field and Tech each retain their own integrity tools. Mutability is limited to each Demo's documented local setup, browser/cache, output and Owner configuration paths; both site/ directories remain immutable. No check authenticates an untrusted distribution source.

Original Field technical acceptance (176/13/33/8) is reused; this integration checks new package consumption and routes. Actual cloud, device, Safari, Linux and final user visual acceptance remain open.

Current Field Owner: field-miner-playwright-unified-20261010; declared commit 8ce386f2f2987c8a4d6ab327e4f9777abc7b061f. Owner tools lock Playwright 1.63.0 / Chromium 153; site105 and source137 bytes are unchanged. Independent final Owner setup plus 33 tool / 8 budget / 13 migration checks passed. Two worker 176-case runs were reviewed with 225 matching functional inputs; they are not claimed as root full-regression reruns. Existing SITE-RECORD Runtime identity is deliberately unchanged.

Tech full approved Owner/history stays archived separately. No source ZIP or1311 historical evidence files are embedded here. Optional source hashes and filenames are in VERSION-INDEX.json. Four accepted Tech maintenance advisories, authentication P2 and public/device/manual-rollback limitations remain open.
