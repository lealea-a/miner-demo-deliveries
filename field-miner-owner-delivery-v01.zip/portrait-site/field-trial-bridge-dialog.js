import {
  fieldTrialBridgeQrGeometry,
  fieldTrialBridgeSurfaceGeometry,
} from './field-trial-bridge-geometry.js';
!function(t,e){"object"==typeof exports&&"undefined"!=typeof module?e(exports):"function"==typeof define&&define.amd?define(["exports"],e):e((t="undefined"!=typeof globalThis?globalThis:t||self).FloatingUICore={})}(this,(function(t){"use strict";const e=["top","right","bottom","left"],n=["start","end"],i=e.reduce(((t,e)=>t.concat(e,e+"-"+n[0],e+"-"+n[1])),[]),r=Math.min,o=Math.max,l={left:"right",right:"left",bottom:"top",top:"bottom"};function a(t,e,n){return o(t,r(e,n))}function s(t,e){return"function"==typeof t?t(e):t}function f(t){return t.split("-")[0]}function c(t){return t.split("-")[1]}function u(t){return"x"===t?"y":"x"}function m(t){return"y"===t?"height":"width"}function d(t){const e=t[0];return"t"===e||"b"===e?"y":"x"}function g(t){return u(d(t))}function p(t,e,n){void 0===n&&(n=!1);const i=c(t),r=g(t),o=m(r);let l="x"===r?i===(n?"end":"start")?"right":"left":"start"===i?"bottom":"top";return e.reference[o]>e.floating[o]&&(l=A(l)),[l,A(l)]}function h(t){return t.includes("start")?t.replace("start","end"):t.replace("end","start")}const y=["left","right"],w=["right","left"],x=["top","bottom"],v=["bottom","top"];function b(t,e,n,i){const r=c(t);let o=function(t,e,n){switch(t){case"top":case"bottom":return n?e?w:y:e?y:w;case"left":case"right":return e?x:v;default:return[]}}(f(t),"start"===n,i);return r&&(o=o.map((t=>t+"-"+r)),e&&(o=o.concat(o.map(h)))),o}function A(t){const e=f(t);return l[e]+t.slice(e.length)}function R(t){return"number"!=typeof t?function(t){var e,n,i,r;return{top:null!=(e=t.top)?e:0,right:null!=(n=t.right)?n:0,bottom:null!=(i=t.bottom)?i:0,left:null!=(r=t.left)?r:0}}(t):{top:t,right:t,bottom:t,left:t}}function O(t){const{x:e,y:n,width:i,height:r}=t;return{width:i,height:r,top:n,left:e,right:e+i,bottom:n+r,x:e,y:n}}function P(t,e,n){let{reference:i,floating:r}=t;const o=d(e),l=g(e),a=m(l),s=f(e),u="y"===o,p=i.x+i.width/2-r.width/2,h=i.y+i.height/2-r.height/2,y=i[a]/2-r[a]/2;let w;switch(s){case"top":w={x:p,y:i.y-r.height};break;case"bottom":w={x:p,y:i.y+i.height};break;case"right":w={x:i.x+i.width,y:h};break;case"left":w={x:i.x-r.width,y:h};break;default:w={x:i.x,y:i.y}}const x=c(e);return x&&(w[l]+=y*("end"===x?1:-1)*(n&&u?-1:1)),w}async function T(t,e){var n;void 0===e&&(e={});const{x:i,y:r,platform:o,rects:l,elements:a,strategy:f}=t,{boundary:c="clippingAncestors",rootBoundary:u="viewport",elementContext:m="floating",altBoundary:d=!1,padding:g=0}=s(e,t),p=R(g),h=a[d?"floating"===m?"reference":"floating":m],y=O(await o.getClippingRect({element:null==(n=await(null==o.isElement?void 0:o.isElement(h)))||n?h:h.contextElement||await(null==o.getDocumentElement?void 0:o.getDocumentElement(a.floating)),boundary:c,rootBoundary:u,strategy:f})),w="floating"===m?{x:i,y:r,width:l.floating.width,height:l.floating.height}:l.reference,x=await(null==o.getOffsetParent?void 0:o.getOffsetParent(a.floating)),v=await(null==o.isElement?void 0:o.isElement(x))&&await(null==o.getScale?void 0:o.getScale(x))||{x:1,y:1},b=O(o.convertOffsetParentRelativeRectToViewportRelativeRect?await o.convertOffsetParentRelativeRectToViewportRelativeRect({elements:a,rect:w,offsetParent:x,strategy:f}):w);return{top:(y.top-b.top+p.top)/v.y,bottom:(b.bottom-y.bottom+p.bottom)/v.y,left:(y.left-b.left+p.left)/v.x,right:(b.right-y.right+p.right)/v.x}}function D(t,e){return{top:t.top-e.height,right:t.right-e.width,bottom:t.bottom-e.height,left:t.left-e.width}}function E(t){return e.some((e=>t[e]>=0))}function L(t){const e=r(...t.map((t=>t.left))),n=r(...t.map((t=>t.top)));return{x:e,y:n,width:o(...t.map((t=>t.right)))-e,height:o(...t.map((t=>t.bottom)))-n}}const k=new Set(["left","top"]);t.arrow=t=>({name:"arrow",options:t,async fn(e){const{x:n,y:i,placement:o,rects:l,platform:f,elements:u,middlewareData:d}=e,{element:p,padding:h=0}=s(t,e)||{};if(null==p)return{};const y=R(h),w={x:n,y:i},x=g(o),v=m(x),b=await f.getDimensions(p),A="y"===x,O=A?"top":"left",P=A?"bottom":"right",T=A?"clientHeight":"clientWidth",D=l.reference[v]+l.reference[x]-w[x]-l.floating[v],E=w[x]-l.reference[x],L=await(null==f.getOffsetParent?void 0:f.getOffsetParent(p));let k=L?L[T]:0;k&&await(null==f.isElement?void 0:f.isElement(L))||(k=u.floating[T]||l.floating[v]);const C=D/2-E/2,H=k/2-b[v]/2-1,S=r(y[O],H),B=r(y[P],H),F=k-b[v]-B,j=k/2-b[v]/2+C,z=a(S,j,F),M=!d.arrow&&null!=c(o)&&j!==z&&l.reference[v]/2-(j<S?S:B)-b[v]/2<0,V=M?j<S?j-S:j-F:0;return{[x]:w[x]+V,data:{[x]:z,centerOffset:j-z-V,...M&&{alignmentOffset:V}},reset:M}}}),t.autoPlacement=function(t){return void 0===t&&(t={}),{name:"autoPlacement",options:t,async fn(e){var n,r,o;const{rects:l,middlewareData:a,placement:u,platform:m,elements:d}=e,{crossAxis:g=!1,alignment:y,allowedPlacements:w=i,autoAlignment:x=!0,...v}=s(t,e),b=void 0!==y||w===i?function(t,e,n){return(t?[...n.filter((e=>c(e)===t)),...n.filter((e=>c(e)!==t))]:n.filter((t=>f(t)===t))).filter((n=>!t||c(n)===t||!!e&&h(n)!==n))}(y||null,x,w):w,A=(null==(n=a.autoPlacement)?void 0:n.index)||0,R=b[A];if(null==R)return{};if(u!==R)return{reset:{placement:b[0]}};const O=await m.detectOverflow(e,v),P=p(R,l,await(null==m.isRTL?void 0:m.isRTL(d.floating))),T=[O[f(R)],O[P[0]],O[P[1]]],D=[...(null==(r=a.autoPlacement)?void 0:r.overflows)||[],{placement:R,overflows:T}],E=b[A+1];if(E)return{data:{index:A+1,overflows:D},reset:{placement:E}};const L=D.map((t=>{const e=c(t.placement);return[t.placement,e&&g?t.overflows.slice(0,2).reduce(((t,e)=>t+e),0):t.overflows[0],t.overflows]})).sort(((t,e)=>t[1]-e[1])),k=(null==(o=L.filter((t=>t[2].slice(0,c(t[0])?2:3).every((t=>t<=0))))[0])?void 0:o[0])||L[0][0];return k!==u?{data:{index:A+1,overflows:D},reset:{placement:k}}:{}}}},t.computePosition=async(t,e,n)=>{const{placement:i="bottom",strategy:r="absolute",middleware:o=[],platform:l}=n,a=l.detectOverflow?l:{...l,detectOverflow:T},s=await(null==l.isRTL?void 0:l.isRTL(e));let f=await l.getElementRects({reference:t,floating:e,strategy:r}),{x:c,y:u}=P(f,i,s),m=i,d=0;const g={};for(let n=0;n<o.length;n++){const p=o[n];if(!p)continue;const{name:h,fn:y}=p,{x:w,y:x,data:v,reset:b}=await y({x:c,y:u,initialPlacement:i,placement:m,strategy:r,middlewareData:g,rects:f,platform:a,elements:{reference:t,floating:e}});c=null!=w?w:c,u=null!=x?x:u,g[h]={...g[h],...v},b&&d<50&&(d++,"object"==typeof b&&(b.placement&&(m=b.placement),b.rects&&(f=!0===b.rects?await l.getElementRects({reference:t,floating:e,strategy:r}):b.rects),({x:c,y:u}=P(f,m,s))),n=-1)}return{x:c,y:u,placement:m,strategy:r,middlewareData:g}},t.detectOverflow=T,t.flip=function(t){return void 0===t&&(t={}),{name:"flip",options:t,async fn(e){var n,i;const{placement:r,middlewareData:o,rects:l,initialPlacement:a,platform:c,elements:u}=e,{mainAxis:m=!0,crossAxis:g=!0,fallbackPlacements:y,fallbackStrategy:w="bestFit",fallbackAxisSideDirection:x="none",flipAlignment:v=!0,...R}=s(t,e);if(null!=(n=o.arrow)&&n.alignmentOffset)return{};const O=f(r),P=d(a),T=f(a)===a,D=await(null==c.isRTL?void 0:c.isRTL(u.floating)),E=y||(T||!v?[A(a)]:function(t){const e=A(t);return[h(t),e,h(e)]}(a)),L="none"!==x;!y&&L&&E.push(...b(a,v,x,D));const k=[a,...E],C=await c.detectOverflow(e,R),H=[];let S=(null==(i=o.flip)?void 0:i.overflows)||[];if(m&&H.push(C[O]),g){const t=p(r,l,D);H.push(C[t[0]],C[t[1]])}if(S=[...S,{placement:r,overflows:H}],!H.every((t=>t<=0))){var B,F;const t=((null==(B=o.flip)?void 0:B.index)||0)+1,e=k[t];if(e){if(!("alignment"===g&&P!==d(e))||S.every((t=>d(t.placement)!==P||t.overflows[0]>0)))return{data:{index:t,overflows:S},reset:{placement:e}}}let n=null==(F=S.filter((t=>t.overflows[0]<=0)).sort(((t,e)=>t.overflows[1]-e.overflows[1]))[0])?void 0:F.placement;if(!n)switch(w){case"bestFit":{var j;const t=null==(j=S.filter((t=>{if(L){const e=d(t.placement);return e===P||"y"===e}return!0})).map((t=>[t.placement,t.overflows.filter((t=>t>0)).reduce(((t,e)=>t+e),0)])).sort(((t,e)=>t[1]-e[1]))[0])?void 0:j[0];t&&(n=t);break}case"initialPlacement":n=a}if(r!==n)return{reset:{placement:n}}}return{}}}},t.hide=function(t){return void 0===t&&(t={}),{name:"hide",options:t,async fn(e){const{rects:n,platform:i}=e,{strategy:r="referenceHidden",...o}=s(t,e);switch(r){case"referenceHidden":{const t=D(await i.detectOverflow(e,{...o,elementContext:"reference"}),n.reference);return{data:{referenceHiddenOffsets:t,referenceHidden:E(t)}}}case"escaped":{const t=D(await i.detectOverflow(e,{...o,altBoundary:!0}),n.floating);return{data:{escapedOffsets:t,escaped:E(t)}}}default:return{}}}}},t.inline=function(t){return void 0===t&&(t={}),{name:"inline",options:t,async fn(e){const{placement:n,elements:i,rects:l,platform:a,strategy:c}=e,{padding:u=2,x:m,y:g}=s(t,e),p=Array.from(await(null==a.getClientRects?void 0:a.getClientRects(i.reference))||[]);if(!p.length)return{};const h=function(t){const e=t.slice().sort(((t,e)=>t.y-e.y)),n=[];let i=null;for(let t=0;t<e.length;t++){const r=e[t];!i||r.y-i.y>i.height/2?n.push([r]):n[n.length-1].push(r),i=r}return n.map((t=>O(L(t))))}(p),y=O(L(p)),w=R(u);const x=await a.getElementRects({reference:{getBoundingClientRect:function(){if(2===h.length&&(h[0].left>h[1].right||h[1].left>h[0].right)&&null!=m&&null!=g)return h.find((t=>m>t.left-w.left&&m<t.right+w.right&&g>t.top-w.top&&g<t.bottom+w.bottom))||y;if(h.length>=2){if("y"===d(n)){const t=h[0],e=h[h.length-1],i="top"===f(n),r=t.top,o=e.bottom,l=i?t.left:e.left;return O({x:l,y:r,width:(i?t.right:e.right)-l,height:o-r})}const t="left"===f(n),e=o(...h.map((t=>t.right))),i=r(...h.map((t=>t.left))),l=h.filter((n=>t?n.left===i:n.right===e)),a=l[0].top,s=l[l.length-1].bottom;return O({x:i,y:a,width:e-i,height:s-a})}return y}},floating:i.floating,strategy:c});return l.reference.x!==x.reference.x||l.reference.y!==x.reference.y||l.reference.width!==x.reference.width||l.reference.height!==x.reference.height?{reset:{rects:x}}:{}}}},t.limitShift=function(t){return void 0===t&&(t={}),{options:t,fn(e){var n,i;const{x:r,y:o,placement:l,rects:a,middlewareData:c}=e,{offset:m=0,mainAxis:g=!0,crossAxis:p=!0}=s(t,e),h={x:r,y:o},y=d(l),w=u(y);let x=h[w],v=h[y];const b=s(m,e),A="number"==typeof b?{mainAxis:b,crossAxis:0}:{mainAxis:null!=(n=b.mainAxis)?n:0,crossAxis:null!=(i=b.crossAxis)?i:0};if(g){const t="y"===w?"height":"width",e=a.reference[w]-a.floating[t]+A.mainAxis,n=a.reference[w]+a.reference[t]-A.mainAxis;x<e?x=e:x>n&&(x=n)}if(p){var R,O;const t="y"===w?"width":"height",e=k.has(f(l)),n=a.reference[y]-a.floating[t]+(e&&(null==(R=c.offset)?void 0:R[y])||0)+(e?0:A.crossAxis),i=a.reference[y]+a.reference[t]+(e?0:(null==(O=c.offset)?void 0:O[y])||0)-(e?A.crossAxis:0);v<n?v=n:v>i&&(v=i)}return{[w]:x,[y]:v}}}},t.offset=function(t){return void 0===t&&(t=0),{name:"offset",options:t,async fn(e){var n,i;const{x:r,y:o,placement:l,middlewareData:a}=e,u=await async function(t,e){const{placement:n,platform:i,elements:r}=t,o=await(null==i.isRTL?void 0:i.isRTL(r.floating)),l=f(n),a=c(n),u="y"===d(n),m=k.has(l)?-1:1,g=o&&u?-1:1,p=s(e,t);let{mainAxis:h,crossAxis:y,alignmentAxis:w}="number"==typeof p?{mainAxis:p,crossAxis:0,alignmentAxis:null}:{mainAxis:p.mainAxis||0,crossAxis:p.crossAxis||0,alignmentAxis:p.alignmentAxis};return a&&"number"==typeof w&&(y="end"===a?-1*w:w),u?{x:y*g,y:h*m}:{x:h*m,y:y*g}}(e,t);return l===(null==(n=a.offset)?void 0:n.placement)&&null!=(i=a.arrow)&&i.alignmentOffset?{}:{x:r+u.x,y:o+u.y,data:{...u,placement:l}}}}},t.rectToClientRect=O,t.shift=function(t){return void 0===t&&(t={}),{name:"shift",options:t,async fn(e){const{x:n,y:i,placement:r,platform:o}=e,{mainAxis:l=!0,crossAxis:f=!1,limiter:c={fn:t=>{let{x:e,y:n}=t;return{x:e,y:n}}},...m}=s(t,e),g={x:n,y:i},p=await o.detectOverflow(e,m),h=d(r),y=u(h);let w=g[y],x=g[h];const v=(t,e)=>a(e+p["y"===t?"top":"left"],e,e-p["y"===t?"bottom":"right"]);l&&(w=v(y,w)),f&&(x=v(h,x));const b=c.fn({...e,[y]:w,[h]:x});return{...b,data:{x:b.x-n,y:b.y-i,enabled:{[y]:l,[h]:f}}}}}},t.size=function(t){return void 0===t&&(t={}),{name:"size",options:t,async fn(e){const{placement:n,rects:i,platform:l,elements:a}=e,{apply:u=()=>{},...m}=s(t,e),g=await l.detectOverflow(e,m),p=f(n),h=c(n),y="y"===d(n),{width:w,height:x}=i.floating;let v,b;"top"===p||"bottom"===p?(v=p,b=h===(await(null==l.isRTL?void 0:l.isRTL(a.floating))?"start":"end")?"left":"right"):(b=p,v="end"===h?"top":"bottom");const A=x-g.top-g.bottom,R=w-g.left-g.right,O=r(x-g[v],A),P=r(w-g[b],R),T=e.middlewareData.shift,D=!T;let E=O,L=P;null!=T&&T.enabled.x&&(L=R),null!=T&&T.enabled.y&&(E=A),D&&!h&&(y?L=w-2*o(g.left,g.right):E=x-2*o(g.top,g.bottom)),await u({...e,availableWidth:L,availableHeight:E});const k=await l.getDimensions(a.floating);return w!==k.width||x!==k.height?{reset:{rects:!0}}:{}}}}}));

!function(t,e){"object"==typeof exports&&"undefined"!=typeof module?e(exports,require("@floating-ui/core")):"function"==typeof define&&define.amd?define(["exports","@floating-ui/core"],e):e((t="undefined"!=typeof globalThis?globalThis:t||self).FloatingUIDOM={},t.FloatingUICore)}(this,(function(t,e){"use strict";const n=Math.min,o=Math.max,i=Math.round,r=Math.floor,l=t=>({x:t,y:t});function c(){return"undefined"!=typeof window}function s(t){return a(t)?(t.nodeName||"").toLowerCase():"#document"}function f(t){var e;return(null==t||null==(e=t.ownerDocument)?void 0:e.defaultView)||window}function u(t){var e;return null==(e=(a(t)?t.ownerDocument:t.document)||window.document)?void 0:e.documentElement}function a(t){return!!c()&&(t instanceof Node||t instanceof f(t).Node)}function d(t){return!!c()&&(t instanceof Element||t instanceof f(t).Element)}function h(t){return!!c()&&(t instanceof HTMLElement||t instanceof f(t).HTMLElement)}function p(t){return!(!c()||"undefined"==typeof ShadowRoot)&&(t instanceof ShadowRoot||t instanceof f(t).ShadowRoot)}function g(t){const{overflow:e,overflowX:n,overflowY:o,display:i}=C(t);return/auto|scroll|overlay|hidden|clip/.test(e+o+n)&&"inline"!==i&&"contents"!==i}function m(t){return/^(table|td|th)$/.test(s(t))}function y(t){try{if(t.matches(":popover-open"))return!0}catch(t){}try{return t.matches(":modal")}catch(t){return!1}}const w=/transform|translate|scale|rotate|perspective|filter/,v=/paint|layout|strict|content/,x=t=>!!t&&"none"!==t;let b;function L(t){const e=d(t)?C(t):t;return x(e.transform)||x(e.translate)||x(e.scale)||x(e.rotate)||x(e.perspective)||!R()&&(x(e.backdropFilter)||x(e.filter))||w.test(e.willChange||"")||v.test(e.contain||"")}function R(){return null==b&&(b="undefined"!=typeof CSS&&CSS.supports&&CSS.supports("-webkit-backdrop-filter","none")),b}function T(t){return/^(html|body|#document)$/.test(s(t))}function C(t){return f(t).getComputedStyle(t)}function S(t){return d(t)?{scrollLeft:t.scrollLeft,scrollTop:t.scrollTop}:{scrollLeft:t.scrollX,scrollTop:t.scrollY}}function E(t){if("html"===s(t))return t;const e=t.assignedSlot||t.parentNode||p(t)&&t.host||u(t);return p(e)?e.host:e}function F(t){const e=E(t);return T(e)?(t.ownerDocument||t).body:h(e)&&g(e)?e:F(e)}function O(t,e,n){var o;void 0===e&&(e=[]),void 0===n&&(n=!0);const i=F(t),r=i===(null==(o=t.ownerDocument)?void 0:o.body),l=f(i);if(r){const t=D(l);return e.concat(l,l.visualViewport||[],g(i)?i:[],t&&n?O(t):[])}return e.concat(i,O(i,[],n))}function D(t){return t.parent&&Object.getPrototypeOf(t.parent)?t.frameElement:null}function W(t){const e=C(t);let n=parseFloat(e.width)||0,o=parseFloat(e.height)||0;const r=h(t),l=r?t.offsetWidth:n,c=r?t.offsetHeight:o,s=i(n)!==l||i(o)!==c;return s&&(n=l,o=c),{width:n,height:o,$:s}}function M(t){return d(t)?t:t.contextElement}function z(t){const e=M(t);if(!h(e))return l(1);const n=e.getBoundingClientRect(),{width:o,height:r,$:c}=W(e);let s=(c?i(n.width):n.width)/o,f=(c?i(n.height):n.height)/r;return s&&Number.isFinite(s)||(s=1),f&&Number.isFinite(f)||(f=1),{x:s,y:f}}const H=l(0);function P(t){const e=f(t);return R()&&e.visualViewport?{x:e.visualViewport.offsetLeft,y:e.visualViewport.offsetTop}:H}function V(t,n,o,i){void 0===n&&(n=!1),void 0===o&&(o=!1);const r=t.getBoundingClientRect(),c=M(t);let s=l(1);n&&(i?d(i)&&(s=z(i)):s=z(t));const u=function(t,e,n){return void 0===e&&(e=!1),!!n&&e&&n===f(t)}(c,o,i)?P(c):l(0);let a=(r.left+u.x)/s.x,h=(r.top+u.y)/s.y,p=r.width/s.x,g=r.height/s.y;if(c&&i){const t=f(c),e=d(i)?f(i):i;let n=t,o=D(n);for(;o&&e!==n;){const t=z(o),e=o.getBoundingClientRect(),i=C(o),r=e.left+(o.clientLeft+parseFloat(i.paddingLeft))*t.x,l=e.top+(o.clientTop+parseFloat(i.paddingTop))*t.y;a*=t.x,h*=t.y,p*=t.x,g*=t.y,a+=r,h+=l,n=f(o),o=D(n)}}return e.rectToClientRect({width:p,height:g,x:a,y:h})}function A(t,e){const n=S(t).scrollLeft;return e?e.left+n:V(u(t)).left+n}function B(t,e){const n=t.getBoundingClientRect();return{x:n.left+e.scrollLeft-A(t,n),y:n.top+e.scrollTop}}function N(t,n,i){let r;if("viewport"===n||"layoutViewport"===n)r=function(t,e,n){void 0===n&&(n="viewport");const o="layoutViewport"===n,i=f(t),r=u(t),l=i.visualViewport;let c=r.clientWidth,s=r.clientHeight,a=0,d=0;if(l){const t=!R()||"fixed"===e;o?t||(a=-l.offsetLeft,d=-l.offsetTop):(c=l.width,s=l.height,t&&(a=l.offsetLeft,d=l.offsetTop))}if(A(r)<=0){const t=r.ownerDocument,e=t.body,n=getComputedStyle(e),o="CSS1Compat"===t.compatMode&&parseFloat(n.marginLeft)+parseFloat(n.marginRight)||0,i=Math.abs(r.clientWidth-e.clientWidth-o),l="stable both-edges"===getComputedStyle(r).scrollbarGutter?i/2:i;l<=25&&(c-=l)}return{width:c,height:s,x:a,y:d}}(t,i,n);else if("document"===n)r=function(t){const e=S(t),n=t.ownerDocument.body,i=o(t.scrollWidth,t.clientWidth,n.scrollWidth,n.clientWidth),r=o(t.scrollHeight,t.clientHeight,n.scrollHeight,n.clientHeight);let l=-e.scrollLeft+A(t);const c=-e.scrollTop;return"rtl"===C(n).direction&&(l+=o(t.clientWidth,n.clientWidth)-i),{width:i,height:r,x:l,y:c}}(u(t));else if(d(n))r=function(t,e){const n=V(t,!0,"fixed"===e),o=n.top+t.clientTop,i=n.left+t.clientLeft,r=z(t);return{width:t.clientWidth*r.x,height:t.clientHeight*r.y,x:i*r.x,y:o*r.y}}(n,i);else{const e=P(t);r={x:n.x-e.x,y:n.y-e.y,width:n.width,height:n.height}}return e.rectToClientRect(r)}function I(t,e,n){const o=h(e),i=u(e),r="fixed"===n,c=V(t,!0,r,e);let f={scrollLeft:0,scrollTop:0};const a=l(0);if((o||!r)&&(("body"!==s(e)||g(i))&&(f=S(e)),o)){const t=V(e,!0,r,e);a.x=t.x+e.clientLeft,a.y=t.y+e.clientTop}!o&&i&&(a.x=A(i));const d=!i||o||r?l(0):B(i,f);return{x:c.left+f.scrollLeft-a.x-d.x,y:c.top+f.scrollTop-a.y-d.y,width:c.width,height:c.height}}function $(t){return"static"===C(t).position}function k(t,e){if(!h(t)||"fixed"===C(t).position)return null;if(e)return e(t);let n=t.offsetParent;return u(t)===n&&(n=n.ownerDocument.body),n}function q(t,e){const n=f(t);if(y(t))return n;if(!h(t)){let e=E(t);for(;e&&!T(e);){if(d(e)&&!$(e))return e;e=E(e)}return n}let o=k(t,e);for(;o&&m(o)&&$(o);)o=k(o,e);return o&&T(o)&&$(o)&&!L(o)?n:o||function(t){let e=E(t);for(;h(e)&&!T(e);){if(L(e))return e;if(y(e))return null;e=E(e)}return null}(t)||n}const U={convertOffsetParentRelativeRectToViewportRelativeRect:function(t){let{elements:e,rect:n,offsetParent:o,strategy:i}=t;const r="fixed"===i,c=u(o),f=!!e&&y(e.floating);if(o===c||f&&r)return n;let a={scrollLeft:0,scrollTop:0},d=l(1);const p=l(0),m=h(o);if((m||!r)&&(("body"!==s(o)||g(c))&&(a=S(o)),m)){const t=V(o);d=z(o),p.x=t.x+o.clientLeft,p.y=t.y+o.clientTop}const w=!c||m||r?l(0):B(c,a);return{width:n.width*d.x,height:n.height*d.y,x:n.x*d.x-a.scrollLeft*d.x+p.x+w.x,y:n.y*d.y-a.scrollTop*d.y+p.y+w.y}},getDocumentElement:u,getClippingRect:function(t){let{element:e,boundary:i,rootBoundary:r,strategy:l}=t;const c=[..."clippingAncestors"===i?y(e)?[]:function(t,e){const n=e.get(t);if(n)return n;let o=O(t,[],!1).filter((t=>d(t)&&"body"!==s(t))),i=null;const r="fixed"===C(t).position;let l=r?E(t):t;for(;d(l)&&!T(l);){const t=C(l),e=L(l),n=i?i.position:r?"fixed":"";e||"fixed"!==n&&("absolute"!==n||"static"!==t.position)?i=t:o=o.filter((t=>t!==l)),l=E(l)}return e.set(t,o),o}(e,this._c):[].concat(i),r],f=N(e,c[0],l);let u=f.top,a=f.right,h=f.bottom,p=f.left;for(let t=1;t<c.length;t++){const i=N(e,c[t],l);u=o(i.top,u),a=n(i.right,a),h=n(i.bottom,h),p=o(i.left,p)}return{width:a-p,height:h-u,x:p,y:u}},getOffsetParent:q,getElementRects:async function(t){const e=this.getOffsetParent||q,n=this.getDimensions,o=await n(t.floating);return{reference:I(t.reference,await e(t.floating),t.strategy),floating:{x:0,y:0,width:o.width,height:o.height}}},getClientRects:function(t){return t.getClientRects?Array.from(t.getClientRects()):[]},getDimensions:function(t){const{width:e,height:n}=W(t);return{width:e,height:n}},getScale:z,isElement:d,isRTL:function(t){return"rtl"===C(t).direction}};function j(t,e){return t.x===e.x&&t.y===e.y&&t.width===e.width&&t.height===e.height}const X=e.detectOverflow,Y=e.offset,_=e.autoPlacement,G=e.shift,J=e.flip,K=e.size,Q=e.hide,Z=e.arrow,tt=e.inline,et=e.limitShift;t.arrow=Z,t.autoPlacement=_,t.autoUpdate=function(t,e,i,l){void 0===l&&(l={});const{ancestorScroll:c=!0,ancestorResize:s=!0,elementResize:a="function"==typeof ResizeObserver,layoutShift:d="function"==typeof IntersectionObserver,animationFrame:h=!1}=l,p=M(t),g=c||s?[...p?O(p):[],...e?O(e):[]]:[];g.forEach((t=>{c&&t.addEventListener("scroll",i),s&&t.addEventListener("resize",i)}));const m=p&&d?function(t,e,i){let l,c=null;const s=u(t);function a(){var t;clearTimeout(l),null==(t=c)||t.disconnect(),c=null}function d(i,f){void 0===i&&(i=!1),void 0===f&&(f=1),a();const u=t.getBoundingClientRect(),{left:h,top:p,width:g,height:m}=u;if(i||e(),!g||!m)return;const y={rootMargin:-r(p)+"px "+-r(s.clientWidth-(h+g))+"px "+-r(s.clientHeight-(p+m))+"px "+-r(h)+"px",threshold:o(0,n(1,f))||1};let w=!0;function v(e){const n=e[0].intersectionRatio;if(!j(u,t.getBoundingClientRect()))return d();if(n!==f){if(!w)return d();n?d(!1,n):l=setTimeout((()=>{d(!1,1e-7)}),1e3)}w=!1}try{c=new IntersectionObserver(v,{...y,root:s.ownerDocument})}catch(t){c=new IntersectionObserver(v,y)}c.observe(t)}const h=f(t),p=()=>d(i);return h.addEventListener("resize",p),d(!0),()=>{h.removeEventListener("resize",p),a()}}(p,i,s):null;let y,w=-1,v=null;a&&(v=new ResizeObserver((t=>{let[n]=t;n&&n.target===p&&v&&e&&(v.unobserve(e),cancelAnimationFrame(w),w=requestAnimationFrame((()=>{var t;null==(t=v)||t.observe(e)}))),i()})),p&&!h&&v.observe(p),e&&v.observe(e));let x=h?V(t):null;return h&&function e(){const n=V(t);x&&!j(x,n)&&i();x=n,y=requestAnimationFrame(e)}(),i(),()=>{var t;g.forEach((t=>{c&&t.removeEventListener("scroll",i),s&&t.removeEventListener("resize",i)})),null==m||m(),null==(t=v)||t.disconnect(),v=null,h&&cancelAnimationFrame(y)}},t.computePosition=(t,n,o)=>{const i=new Map,r=null!=o?o:{},l={...U,...r.platform,_c:i};return e.computePosition(t,n,{...r,platform:l})},t.detectOverflow=X,t.flip=J,t.getOverflowAncestors=O,t.hide=Q,t.inline=tt,t.limitShift=et,t.offset=Y,t.platform=U,t.shift=G,t.size=K}));



const {
  autoUpdate,
  computePosition,
  offset,
  shift,
} = globalThis.FloatingUIDOM;

const EXCLUDED_TARGET_SELECTOR = [
  'button',
  'a',
  'input',
  'select',
  'textarea',
  '[role="button"]',
  '[data-trial-bridge-no-dismiss]',
].join(',');

function createLightTapGesture({ target, onLightTap }) {
  if (!(target instanceof EventTarget)) {
    throw new Error('LIGHT_TAP_TARGET_REQUIRED');
  }
  if (typeof onLightTap !== 'function') {
    throw new Error('LIGHT_TAP_HANDLER_REQUIRED');
  }

  const abort = new AbortController();
  let pointerStart = null;

  function cancelPointer(pointerId = null) {
    if (pointerStart && (pointerId === null || pointerStart.id === pointerId)) {
      pointerStart = null;
    }
  }

  function handlePointerDown(event) {
    if (pointerStart !== null) {
      pointerStart.cancelled = true;
      return;
    }
    if (!event.isPrimary || event.button !== 0) return;
    if (event.target instanceof Element
      && event.target.closest(EXCLUDED_TARGET_SELECTOR)) return;

    target.setPointerCapture?.(event.pointerId);
    pointerStart = {
      x: event.clientX,
      y: event.clientY,
      time: performance.now(),
      id: event.pointerId,
      cancelled: false,
    };
  }

  function handlePointerUp(event) {
    const start = pointerStart;
    if (!start || start.id !== event.pointerId) return;
    pointerStart = null;

    if (start.cancelled || !event.isPrimary || event.button !== 0) return;
    const distance = Math.hypot(
      event.clientX - start.x,
      event.clientY - start.y,
    );
    const duration = performance.now() - start.time;
    if (distance >= 9 || duration >= 520) return;

    event.preventDefault();
    event.stopPropagation();
    onLightTap(event);
  }

  function handlePointerCancel(event) {
    cancelPointer(event.pointerId);
  }

  const options = { signal: abort.signal };
  target.addEventListener('pointerdown', handlePointerDown, options);
  target.addEventListener('pointerup', handlePointerUp, options);
  target.addEventListener('pointercancel', handlePointerCancel, options);
  target.addEventListener('lostpointercapture', handlePointerCancel, options);

  return Object.freeze({
    destroy() {
      pointerStart = null;
      abort.abort();
    },
  });
}

export function createFieldTrialBridgeDialog({
  root,
  coveredDialog,
  assetUrl,
  onError = null,
}) {
  if (!root?.ownerDocument) throw new Error('FIELD_TRIAL_BRIDGE_ROOT_REQUIRED');
  if (typeof assetUrl !== 'string' || assetUrl.length === 0) {
    throw new Error('FIELD_TRIAL_BRIDGE_ASSET_REQUIRED');
  }
  if (onError !== null && typeof onError !== 'function') {
    throw new Error('FIELD_TRIAL_BRIDGE_ERROR_HANDLER_INVALID');
  }

  const ownerDocument = root.ownerDocument;
  const ownerWindow = ownerDocument.defaultView;
  if (!ownerWindow) throw new Error('FIELD_TRIAL_BRIDGE_WINDOW_REQUIRED');
  if (!(coveredDialog instanceof ownerWindow.HTMLDialogElement)) {
    throw new Error('FIELD_TRIAL_BRIDGE_COVERED_DIALOG_REQUIRED');
  }

  const dialog = ownerDocument.createElement('dialog');
  dialog.className = 'trial-bridge';
  dialog.dataset.role = 'field-trial-bridge';
  dialog.setAttribute('closedby', 'closerequest');
  dialog.setAttribute('aria-label', 'Field Miner 试算出口');

  const surface = ownerDocument.createElement('div');
  surface.className = 'trial-bridge__surface';
  surface.dataset.view = 'bridge';

  const image = ownerDocument.createElement('img');
  image.alt = '';
  image.setAttribute('aria-hidden', 'true');
  image.draggable = false;

  const returnButton = ownerDocument.createElement('button');
  returnButton.type = 'button';
  returnButton.className = 'trial-bridge__return';
  returnButton.setAttribute('aria-label', '返回 Demo');
  returnButton.textContent = '← 返回 Demo';

  const connectButton = ownerDocument.createElement('button');
  connectButton.type = 'button';
  connectButton.className = 'trial-bridge__connect';
  connectButton.setAttribute('aria-label', '接入 EKTO-POD');

  const qrView = ownerDocument.createElement('section');
  qrView.className = 'trial-bridge__qr-view';
  qrView.dataset.view = 'qr';
  qrView.hidden = true;

  const qrTitle = ownerDocument.createElement('h2');
  qrTitle.textContent = '扫码接入 EKTO-POD';
  const qrDescription = ownerDocument.createElement('p');
  qrDescription.textContent = '使用手机扫码，继续输入条件';
  const qrPlaceholder = ownerDocument.createElement('div');
  qrPlaceholder.className = 'trial-bridge__qr-placeholder';
  qrPlaceholder.setAttribute('role', 'img');
  qrPlaceholder.setAttribute('aria-label', '二维码占位符，当前不可扫描');
  const qrMark = ownerDocument.createElement('span');
  qrMark.textContent = 'QR';
  const qrPlaceholderLabel = ownerDocument.createElement('small');
  qrPlaceholderLabel.textContent = 'PLACEHOLDER';
  qrPlaceholder.append(qrMark, qrPlaceholderLabel);
  const qrReturnButton = ownerDocument.createElement('button');
  qrReturnButton.type = 'button';
  qrReturnButton.className = 'trial-bridge__qr-return';
  qrReturnButton.textContent = '点击任意位置返回';
  qrView.append(qrTitle, qrDescription, qrPlaceholder, qrReturnButton);

  surface.append(image, returnButton, connectButton);
  dialog.append(surface, qrView);
  root.append(dialog);

  let destroyed = false;
  let activeView = 'bridge';
  let trigger = null;
  let coveredOverlay = null;
  let cardShell = null;
  let positionCleanup = null;
  let positionUpdate = null;
  let portrait = null;
  let placement = null;
  let loadError = null;

  const assetReady = new ownerWindow.Promise((resolve, reject) => {
    image.addEventListener('load', resolve, { once: true });
    image.addEventListener('error', () => {
      reject(new Error('FIELD_TRIAL_BRIDGE_ASSET_LOAD_FAILED:' + assetUrl));
    }, { once: true });
  }).catch((error) => {
    loadError = error;
    throw error;
  });
  assetReady.catch(() => {});
  image.src = assetUrl;

  function clearPositionTracking() {
    positionCleanup?.();
    positionCleanup = null;
    positionUpdate = null;
  }

  function clearCoveredOverlay() {
    coveredOverlay?.classList.remove('is-bridge-covered');
  }

  function setActiveView(nextView) {
    activeView = nextView;
    surface.hidden = activeView !== 'bridge';
    qrView.hidden = activeView !== 'qr';
  }

  function applyBridgeSize(geometry) {
    dialog.style.width = geometry.width + 'px';
    dialog.style.height = geometry.height + 'px';
    dialog.style.removeProperty('--trial-qr-size');
    dialog.dataset.orientation = geometry.portrait
      ? 'portrait'
      : 'landscape';
  }

  function applyQrSize(geometry) {
    dialog.style.width = geometry.width + 'px';
    dialog.style.height = geometry.height + 'px';
    dialog.style.setProperty('--trial-qr-size', geometry.qrSize + 'px');
    dialog.dataset.orientation = ownerWindow.innerHeight >= ownerWindow.innerWidth
      ? 'portrait'
      : 'landscape';
  }

  async function updateCenteredPosition() {
    if (!dialog.open || !cardShell?.isConnected) return false;
    const result = await computePosition(cardShell, dialog, {
      strategy: 'fixed',
      placement: 'bottom',
      middleware: [
        offset(({ rects }) => (
          -rects.reference.height / 2
          - rects.floating.height / 2
        )),
        shift({
          padding: { top: 16, right: 16, bottom: 16, left: 16 },
          crossAxis: true,
        }),
      ],
    });
    if (!dialog.open) return false;
    dialog.style.left = result.x + 'px';
    dialog.style.top = result.y + 'px';
    placement = 'center';
    dialog.dataset.placement = 'center';
    return true;
  }

  function startPositionTracking() {
    clearPositionTracking();
    const viewportWidth = ownerWindow.innerWidth;
    const viewportHeight = ownerWindow.innerHeight;
    portrait = viewportHeight >= viewportWidth;
    placement = 'center';
    const geometry = activeView === 'qr'
      ? fieldTrialBridgeQrGeometry(viewportWidth, viewportHeight)
      : fieldTrialBridgeSurfaceGeometry(viewportWidth, viewportHeight);
    if (activeView === 'qr') applyQrSize(geometry);
    else applyBridgeSize(geometry);

    if (activeView === 'bridge' && portrait) {
      dialog.style.left = geometry.left + 'px';
      dialog.style.top = geometry.top + 'px';
      dialog.dataset.placement = 'center';
      positionUpdate = () => ownerWindow.Promise.resolve(true);
      return positionUpdate();
    }

    positionUpdate = updateCenteredPosition;
    positionCleanup = autoUpdate(
      cardShell,
      dialog,
      positionUpdate,
      {
        ancestorScroll: false,
        ancestorResize: true,
        elementResize: true,
        layoutShift: true,
        animationFrame: false,
      },
    );
    return positionUpdate();
  }

  async function refreshPosition() {
    if (!dialog.open) return false;
    dialog.removeAttribute('data-positioned');
    const positioned = await startPositionTracking();
    if (dialog.open && positioned) dialog.dataset.positioned = '';
    return positioned;
  }

  async function switchView(nextView, focusTarget) {
    if (!dialog.open || activeView === nextView) {
      focusTarget?.focus({ preventScroll: true });
      return dialog.open;
    }
    dialog.removeAttribute('data-positioned');
    setActiveView(nextView);
    try {
      const positioned = await startPositionTracking();
      if (!dialog.open || !positioned) return false;
      dialog.dataset.positioned = '';
      focusTarget.focus({ preventScroll: true });
      return true;
    } catch (error) {
      clearCoveredOverlay();
      if (dialog.open) dialog.close();
      onError?.(error);
      throw error;
    }
  }

  const showQrView = () => switchView('qr', qrReturnButton);

  function restoreTriggerFocus() {
    const focusTarget = trigger?.isConnected
      ? trigger
      : coveredDialog.querySelector('[data-field-trial-trigger]');
    trigger = null;
    focusTarget?.focus({ preventScroll: true });
  }

  function finalizeClose() {
    const shouldCloseCoveredDialog = activeView === 'qr';

    clearPositionTracking();
    ownerWindow.removeEventListener('resize', refreshPosition);
    dialog.removeAttribute('data-positioned');
    dialog.removeAttribute('data-placement');
    dialog.removeAttribute('data-orientation');
    portrait = null;
    placement = null;
    setActiveView('bridge');
    dialog.style.removeProperty('--trial-qr-size');
    clearCoveredOverlay();
    coveredOverlay = null;
    cardShell = null;

    if (shouldCloseCoveredDialog) {
      trigger = null;
      if (coveredDialog.open) coveredDialog.close();
      return;
    }

    ownerWindow.queueMicrotask(restoreTriggerFocus);
  }

  function close() {
    if (!dialog.open) return false;
    dialog.close();
    return true;
  }

  async function open(nextTrigger) {
    if (destroyed) throw new Error('FIELD_TRIAL_BRIDGE_DESTROYED');
    if (
      !(nextTrigger instanceof ownerWindow.HTMLButtonElement)
      || !nextTrigger.isConnected
    ) {
      throw new Error('FIELD_TRIAL_BRIDGE_TRIGGER_REQUIRED');
    }
    if (dialog.open) return true;

    try {
      await assetReady;
    } catch (error) {
      onError?.(error);
      throw error;
    }
    if (loadError) {
      onError?.(loadError);
      throw loadError;
    }

    trigger = nextTrigger;
    setActiveView('bridge');
    coveredOverlay = coveredDialog;
    cardShell = coveredDialog;
    const cardRect = cardShell.getBoundingClientRect();
    if (
      !coveredOverlay.open
      || !coveredOverlay.isConnected
      || !coveredOverlay.contains(trigger)
      || cardRect.width <= 0
      || cardRect.height <= 0
    ) {
      coveredOverlay = null;
      cardShell = null;
      throw new Error('FIELD_TRIAL_BRIDGE_ACTIVE_CARD_REQUIRED');
    }
    dialog.removeAttribute('data-positioned');

    try {
      dialog.showModal();
      const positioned = await startPositionTracking();
      if (!dialog.open || !positioned) return false;
      coveredOverlay.classList.add('is-bridge-covered');
      dialog.dataset.positioned = '';
      ownerWindow.addEventListener('resize', refreshPosition);
      returnButton.focus({ preventScroll: true });
      return true;
    } catch (error) {
      clearCoveredOverlay();
      if (dialog.open) dialog.close();
      onError?.(error);
      throw error;
    }
  }

  function snapshot() {
    const rect = dialog.getBoundingClientRect();
    return Object.freeze({
      open: dialog.open,
      positioned: dialog.hasAttribute('data-positioned'),
      activeView,
      portrait,
      placement,
      reference: cardShell ? 'phi-dialog' : null,
      covered: coveredDialog.classList.contains('is-bridge-covered'),
      rect: Object.freeze({
        left: rect.left,
        top: rect.top,
        right: rect.right,
        bottom: rect.bottom,
        width: rect.width,
        height: rect.height,
      }),
    });
  }

  connectButton.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    showQrView().catch(() => {});
  });
  qrReturnButton.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    close();
  });
  returnButton.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    close();
  });
  dialog.addEventListener('cancel', (event) => {
    event.preventDefault();
    close();
  });
  dialog.addEventListener('close', finalizeClose);

  const lightTapGesture = createLightTapGesture({
    target: dialog,
    onLightTap() {
      close();
    },
  });

  function destroy() {
    if (destroyed) return;
    destroyed = true;
    if (dialog.open) dialog.close();
    lightTapGesture.destroy();
    clearPositionTracking();
    ownerWindow.removeEventListener('resize', refreshPosition);
    clearCoveredOverlay();
    dialog.remove();
    trigger = null;
    coveredOverlay = null;
    cardShell = null;
  }

  return Object.freeze({
    dialog,
    open,
    close,
    snapshot,
    destroy,
  });
}
